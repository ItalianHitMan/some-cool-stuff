AddCSLuaFile("shared.lua")
include('shared.lua')
/*-----------------------------------------------
	*** Copyright (c) 2012-2020 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/
ENT.Model = {"models/vj_hlr/theyhunger/nursezombie.mdl"} -- The game will pick a random model from the table when the SNPC is spawned | Add as many as you want
ENT.StartHealth = 50
ENT.HullType = HULL_HUMAN
ENT.VJC_Data = {
    ThirdP_Offset = Vector(-5, 0, -15), -- The offset for the controller when the camera is in third person
    FirstP_Bone = "Bip01 Head", -- If left empty, the base will attempt to calculate a position for first person
    FirstP_Offset = Vector(5, 0, 5), -- The offset for the controller when the camera is in first person
}
---------------------------------------------------------------------------------------------------------------------------------------------
ENT.BloodColor = "Red" -- The blood type, this will determine what it should use (decal, particle, etc.)
ENT.CustomBlood_Particle = {"vj_hl_blood_red"}
ENT.CustomBlood_Decal = {"VJ_HLR_Blood_Red"} -- Decals to spawn when it's damaged
ENT.HasBloodPool = false -- Does it have a blood pool?
ENT.VJ_NPC_Class = {"CLASS_ZOMBIE"} -- NPCs with the same class with be allied to each other

ENT.HasMeleeAttack = true -- Should the SNPC have a melee attack?
ENT.MeleeAttackDistance = 50 -- How close does it have to be until it attacks?
ENT.MeleeAttackDamageDistance = 80 -- How far does the damage go?

ENT.HasExtraMeleeAttackSounds = true -- Set to true to use the extra melee attack sounds
ENT.DisableFootStepSoundTimer = false -- If set to true, it will disable the time system for the footstep sound code, allowing you to use other ways like model events
ENT.FootStepTimeRun = 0.2 -- Next foot step sound when it is running
ENT.FootStepTimeWalk = 0.4 -- Next foot step sound when it is walking
ENT.AnimTbl_Run = {ACT_WALK} -- Set the running animations | Put multiple to let the base pick a random animation when it moves
ENT.HasDeathAnimation = true -- Does it play an animation when it dies?
//ENT.DeathAnimationTime = 0.8 -- Time until the SNPC spawns its corpse and gets removed
ENT.DeathCorpseModel = {"models/vj_hlr/hl1/zombie.mdl"}
	-- ====== Flinching Variables ====== --
ENT.CanFlinch = 1 -- 0 = Don't flinch | 1 = Flinch at any damage | 2 = Flinch only from certain damages
ENT.AnimTbl_Flinch = {"vjseq_flinch"} -- If it uses normal based animation, use this
ENT.HasHitGroupFlinching = true -- It will flinch when hit in certain hitgroups | It can also have certain animations to play in certain hitgroups
ENT.HitGroupFlinching_Values = {
	{HitGroup={HITGROUP_LEFTARM},IsSchedule=false,Animation={ACT_FLINCH_LEFTARM}},
	{HitGroup={HITGROUP_LEFTLEG},IsSchedule=false,Animation={ACT_FLINCH_LEFTLEG}},
	{HitGroup={HITGROUP_RIGHTARM},IsSchedule=false,Animation={ACT_FLINCH_RIGHTARM}},
	{HitGroup={HITGROUP_RIGHTLEG},IsSchedule=false,Animation={ACT_FLINCH_RIGHTLEG}}
} -- if "IsSchedule" is set to true, "Animation" needs to be a schedule
	-- ====== Sound File Paths ====== --
-- Leave blank if you don't want any sounds to play
ENT.SoundTbl_FootStep = {"vj_hlr/pl_step1.wav","vj_hlr/pl_step2.wav","vj_hlr/pl_step3.wav","vj_hlr/pl_step4.wav"}

ENT.GeneralSoundPitch1 = 100

-- Custom
ENT.Zombie_Type = 0
	-- 1 = GlassEye
	-- 2 = Woman
	-- 3 = Default
	-- 4 = Headless
	-- 5 = PoliceJaw
	-- 6 = PoliceFaceless
	-- 7 = PoliceCrowbar
	-- 8 = Suicider
	-- 9 = Chef1
	-- 10 = Chef2
	-- 11 = Chef3
	-- 12 = Priest
	-- 13 = Biohazard
	-- 14 = Burnt
	-- 15 = Nurse
	-- 16 = Doctor
	-- 17 = Patient
	-- 18 = Commander
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnInitialize()
	if self:GetModel() == "models/vj_hlr/theyhunger/zombie_glasseye.mdl" then
	self.Zombie_Type = 1
	self.SoundTbl_Idle = {"vj_hlr/th_npc/hunger/hungerzombie/zo_idle1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle3.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle4.wav"}
	self.SoundTbl_CombatIdle = {"vj_hlr/th_npc/hunger/hungerzombie/zo_idle1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle3.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle4.wav"}
	self.SoundTbl_Alert = {"vj_hlr/th_npc/hunger/hungerzombie/zo_alert10.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_alert20.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_alert30.wav"}
	self.SoundTbl_BeforeMeleeAttack = {"vj_hlr/th_npc/hunger/hungerzombie/zo_attack1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_attack2.wav"}
	self.SoundTbl_MeleeAttackExtra = {"vj_hlr/hl1_npc/zombie/claw_strike1.wav","vj_hlr/hl1_npc/zombie/claw_strike2.wav","vj_hlr/hl1_npc/zombie/claw_strike3.wav"}
	self.SoundTbl_MeleeAttackMiss = {"vj_hlr/hl1_npc/zombie/claw_miss1.wav","vj_hlr/hl1_npc/zombie/claw_miss2.wav"}
	self.SoundTbl_Pain = {"vj_hlr/th_npc/hunger/hungerzombie/zo_pain1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain3.wav"}
	self.SoundTbl_Death = {"vj_hlr/th_npc/hunger/hungerzombie/zo_pain1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain3.wav"}
	end
	if self:GetModel() == "models/vj_hlr/theyhunger/zombie_woman.mdl" then
	self.Zombie_Type = 2
	self.SoundTbl_Idle = {"vj_hlr/th_npc/hunger/hungerzombiefem/zo_idle1.wav","vj_hlr/th_npc/hunger/hungerzombiefem/zo_idle2.wav","vj_hlr/th_npc/hunger/hungerzombiefem/zo_idle3.wav","vj_hlr/th_npc/hunger/hungerzombiefem/zo_idle4.wav"}
	self.SoundTbl_CombatIdle = {"vj_hlr/th_npc/hunger/hungerzombiefem/zo_idle1.wav","vj_hlr/th_npc/hunger/hungerzombiefem/zo_idle2.wav","vj_hlr/th_npc/hunger/hungerzombiefem/zo_idle3.wav","vj_hlr/th_npc/hunger/hungerzombiefem/zo_idle4.wav"}
	self.SoundTbl_Alert = {"vj_hlr/th_npc/hunger/hungerzombiefem/zo_alert10.wav","vj_hlr/th_npc/hunger/hungerzombiefem/zo_alert20.wav","vj_hlr/th_npc/hunger/hungerzombiefem/zo_alert30.wav"}
	self.SoundTbl_BeforeMeleeAttack = {"vj_hlr/th_npc/hunger/hungerzombiefem/zo_attack1.wav","vj_hlr/th_npc/hunger/hungerzombiefem/zo_attack2.wav"}
	self.SoundTbl_MeleeAttackExtra = {"vj_hlr/hl1_npc/zombie/claw_strike1.wav","vj_hlr/hl1_npc/zombie/claw_strike2.wav","vj_hlr/hl1_npc/zombie/claw_strike3.wav"}
	self.SoundTbl_MeleeAttackMiss = {"vj_hlr/hl1_npc/zombie/claw_miss1.wav","vj_hlr/hl1_npc/zombie/claw_miss2.wav"}
	self.SoundTbl_Pain = {"vj_hlr/th_npc/hunger/hungerzombiefem/zo_pain1.wav","vj_hlr/th_npc/hunger/hungerzombiefem/zo_pain2.wav"}
	self.SoundTbl_Death = {"vj_hlr/th_npc/hunger/hungerzombiefem/zo_pain1.wav","vj_hlr/th_npc/hunger/hungerzombiefem/zo_pain2.wav"}
	end
	if self:GetModel() == "models/vj_hlr/theyhunger/zombie_normal.mdl" then
	self.Zombie_Type = 3
	self.SoundTbl_Idle = {"vj_hlr/th_npc/hunger/hungerzombie/zo_idle1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle3.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle4.wav"}
	self.SoundTbl_CombatIdle = {"vj_hlr/th_npc/hunger/hungerzombie/zo_idle1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle3.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle4.wav"}
	self.SoundTbl_Alert = {"vj_hlr/th_npc/hunger/hungerzombie/zo_alert10.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_alert20.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_alert30.wav"}
	self.SoundTbl_BeforeMeleeAttack = {"vj_hlr/th_npc/hunger/hungerzombie/zo_attack1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_attack2.wav"}
	self.SoundTbl_MeleeAttackExtra = {"vj_hlr/hl1_npc/zombie/claw_strike1.wav","vj_hlr/hl1_npc/zombie/claw_strike2.wav","vj_hlr/hl1_npc/zombie/claw_strike3.wav"}
	self.SoundTbl_MeleeAttackMiss = {"vj_hlr/hl1_npc/zombie/claw_miss1.wav","vj_hlr/hl1_npc/zombie/claw_miss2.wav"}
	self.SoundTbl_Pain = {"vj_hlr/th_npc/hunger/hungerzombie/zo_pain1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain3.wav"}
	self.SoundTbl_Death = {"vj_hlr/th_npc/hunger/hungerzombie/zo_pain1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain3.wav"}
	end
	if self:GetModel() == "models/vj_hlr/theyhunger/zombie_headless1.mdl" then
	self.Zombie_Type = 4
	self.SoundTbl_Idle = {"vj_hlr/th_npc/hunger/hungerzombie/zo_idle1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle3.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle4.wav"}
	self.SoundTbl_CombatIdle = {"vj_hlr/th_npc/hunger/hungerzombie/zo_idle1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle3.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle4.wav"}
	self.SoundTbl_Alert = {"vj_hlr/th_npc/hunger/hungerzombie/zo_alert10.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_alert20.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_alert30.wav"}
	self.SoundTbl_BeforeMeleeAttack = {"vj_hlr/th_npc/hunger/hungerzombie/zo_attack1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_attack2.wav"}
	self.SoundTbl_MeleeAttackExtra = {"vj_hlr/hl1_npc/zombie/claw_strike1.wav","vj_hlr/hl1_npc/zombie/claw_strike2.wav","vj_hlr/hl1_npc/zombie/claw_strike3.wav"}
	self.SoundTbl_MeleeAttackMiss = {"vj_hlr/hl1_npc/zombie/claw_miss1.wav","vj_hlr/hl1_npc/zombie/claw_miss2.wav"}
	self.SoundTbl_Pain = {"vj_hlr/th_npc/hunger/hungerzombie/zo_pain1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain3.wav"}
	self.SoundTbl_Death = {"vj_hlr/th_npc/hunger/hungerzombie/zo_pain1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain3.wav"}
	end
	if self:GetModel() == "models/vj_hlr/theyhunger/zombie_cop.mdl" then
	self.Zombie_Type = 5
	self.SoundTbl_Idle = {"vj_hlr/th_npc/hunger/hungerzombie/zo_idle1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle3.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle4.wav"}
	self.SoundTbl_CombatIdle = {"vj_hlr/th_npc/hunger/hungerzombie/zo_idle1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle3.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle4.wav"}
	self.SoundTbl_Alert = {"vj_hlr/th_npc/hunger/hungerzombie/zo_alert10.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_alert20.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_alert30.wav"}
	self.SoundTbl_BeforeMeleeAttack = {"vj_hlr/th_npc/hunger/hungerzombie/zo_attack1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_attack2.wav"}
	self.SoundTbl_MeleeAttackExtra = {"vj_hlr/hl1_npc/zombie/claw_strike1.wav","vj_hlr/hl1_npc/zombie/claw_strike2.wav","vj_hlr/hl1_npc/zombie/claw_strike3.wav"}
	self.SoundTbl_MeleeAttackMiss = {"vj_hlr/hl1_npc/zombie/claw_miss1.wav","vj_hlr/hl1_npc/zombie/claw_miss2.wav"}
	self.SoundTbl_Pain = {"vj_hlr/th_npc/hunger/hungerzombie/zo_pain1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain3.wav"}
	self.SoundTbl_Death = {"vj_hlr/th_npc/hunger/hungerzombie/zo_pain1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain3.wav"}
	end
	if self:GetModel() == "models/vj_hlr/theyhunger/zombie2_nofacecop.mdl" then
	self.Zombie_Type = 6
	self.SoundTbl_Idle = {"vj_hlr/th_npc/hunger/hungerzombie/zo_idle1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle3.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle4.wav"}
	self.SoundTbl_CombatIdle = {"vj_hlr/th_npc/hunger/hungerzombie/zo_idle1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle3.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle4.wav"}
	self.SoundTbl_Alert = {"vj_hlr/th_npc/hunger/hungerzombie/zo_alert10.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_alert20.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_alert30.wav"}
	self.SoundTbl_BeforeMeleeAttack = {"vj_hlr/th_npc/hunger/hungerzombie/zo_attack1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_attack2.wav"}
	self.SoundTbl_MeleeAttackExtra = {"vj_hlr/hl1_npc/zombie/claw_strike1.wav","vj_hlr/hl1_npc/zombie/claw_strike2.wav","vj_hlr/hl1_npc/zombie/claw_strike3.wav"}
	self.SoundTbl_MeleeAttackMiss = {"vj_hlr/hl1_npc/zombie/claw_miss1.wav","vj_hlr/hl1_npc/zombie/claw_miss2.wav"}
	self.SoundTbl_Pain = {"vj_hlr/th_npc/hunger/hungerzombie/zo_pain1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain3.wav"}
	self.SoundTbl_Death = {"vj_hlr/th_npc/hunger/hungerzombie/zo_pain1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain3.wav"}
	end
	if self:GetModel() == "models/vj_hlr/theyhunger/zombie2_crowbarcop.mdl" then
	self.Zombie_Type = 7
	self.SoundTbl_Idle = {"vj_hlr/th_npc/hunger/hungerzombie/zo_idle1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle3.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle4.wav"}
	self.SoundTbl_CombatIdle = {"vj_hlr/th_npc/hunger/hungerzombie/zo_idle1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle3.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle4.wav"}
	self.SoundTbl_Alert = {"vj_hlr/th_npc/hunger/hungerzombie/zo_alert10.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_alert20.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_alert30.wav"}
	self.SoundTbl_BeforeMeleeAttack = {"vj_hlr/th_npc/hunger/hungerzombie/zo_attack1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_attack2.wav"}
	self.SoundTbl_MeleeAttackExtra = {"vj_hlr/hl1_npc/zombie/claw_strike1.wav","vj_hlr/hl1_npc/zombie/claw_strike2.wav","vj_hlr/hl1_npc/zombie/claw_strike3.wav"}
	self.SoundTbl_MeleeAttackMiss = {"vj_hlr/hl1_npc/zombie/claw_miss1.wav","vj_hlr/hl1_npc/zombie/claw_miss2.wav"}
	self.SoundTbl_Pain = {"vj_hlr/th_npc/hunger/hungerzombie/zo_pain1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain3.wav"}
	self.SoundTbl_Death = {"vj_hlr/th_npc/hunger/hungerzombie/zo_pain1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain3.wav"}
	end
	if self:GetModel() == "models/vj_hlr/theyhunger/zombie2_coolzombie.mdl" then
	self.Zombie_Type = 8
	self.SoundTbl_Idle = {"vj_hlr/th_npc/hunger/hungerzombie/zo_idle1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle3.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle4.wav"}
	self.SoundTbl_CombatIdle = {"vj_hlr/th_npc/hunger/hungerzombie/zo_idle1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle3.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle4.wav"}
	self.SoundTbl_Alert = {"vj_hlr/th_npc/hunger/hungerzombie/zo_alert10.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_alert20.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_alert30.wav"}
	self.SoundTbl_BeforeMeleeAttack = {"vj_hlr/th_npc/hunger/hungerzombie/zo_attack1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_attack2.wav"}
	self.SoundTbl_MeleeAttackExtra = {"vj_hlr/hl1_npc/zombie/claw_strike1.wav","vj_hlr/hl1_npc/zombie/claw_strike2.wav","vj_hlr/hl1_npc/zombie/claw_strike3.wav"}
	self.SoundTbl_MeleeAttackMiss = {"vj_hlr/hl1_npc/zombie/claw_miss1.wav","vj_hlr/hl1_npc/zombie/claw_miss2.wav"}
	self.SoundTbl_Pain = {"vj_hlr/th_npc/hunger/hungerzombie/zo_pain1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain3.wav"}
	self.SoundTbl_Death = {"vj_hlr/th_npc/hunger/hungerzombie/zo_pain1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain3.wav"}
	end
	if self:GetModel() == "models/vj_hlr/theyhunger/zombie2_chefknife.mdl" then
	self.Zombie_Type = 9
	self.SoundTbl_Idle = {"vj_hlr/th_npc/hunger/hungerzombie/zo_idle1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle3.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle4.wav"}
	self.SoundTbl_CombatIdle = {"vj_hlr/th_npc/hunger/hungerzombie/zo_idle1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle3.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle4.wav"}
	self.SoundTbl_Alert = {"vj_hlr/th_npc/hunger/hungerzombie/zo_alert10.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_alert20.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_alert30.wav"}
	self.SoundTbl_BeforeMeleeAttack = {"vj_hlr/th_npc/hunger/hungerzombie/zo_attack1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_attack2.wav"}
	self.SoundTbl_MeleeAttackExtra = {"vj_hlr/hl1_npc/zombie/claw_strike1.wav","vj_hlr/hl1_npc/zombie/claw_strike2.wav","vj_hlr/hl1_npc/zombie/claw_strike3.wav"}
	self.SoundTbl_MeleeAttackMiss = {"vj_hlr/hl1_npc/zombie/claw_miss1.wav","vj_hlr/hl1_npc/zombie/claw_miss2.wav"}
	self.SoundTbl_Pain = {"vj_hlr/th_npc/hunger/hungerzombie/zo_pain1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain3.wav"}
	self.SoundTbl_Death = {"vj_hlr/th_npc/hunger/hungerzombie/zo_pain1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain3.wav"}
	end
	if self:GetModel() == "models/vj_hlr/theyhunger/zombie2_cleverguy.mdl" then
	self.Zombie_Type = 10
	self.SoundTbl_Idle = {"vj_hlr/th_npc/hunger/hungerzombie/zo_idle1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle3.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle4.wav"}
	self.SoundTbl_CombatIdle = {"vj_hlr/th_npc/hunger/hungerzombie/zo_idle1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle3.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle4.wav"}
	self.SoundTbl_Alert = {"vj_hlr/th_npc/hunger/hungerzombie/zo_alert10.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_alert20.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_alert30.wav"}
	self.SoundTbl_BeforeMeleeAttack = {"vj_hlr/th_npc/hunger/hungerzombie/zo_attack1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_attack2.wav"}
	self.SoundTbl_MeleeAttackExtra = {"vj_hlr/hl1_npc/zombie/claw_strike1.wav","vj_hlr/hl1_npc/zombie/claw_strike2.wav","vj_hlr/hl1_npc/zombie/claw_strike3.wav"}
	self.SoundTbl_MeleeAttackMiss = {"vj_hlr/hl1_npc/zombie/claw_miss1.wav","vj_hlr/hl1_npc/zombie/claw_miss2.wav"}
	self.SoundTbl_Pain = {"vj_hlr/th_npc/hunger/hungerzombie/zo_pain1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain3.wav"}
	self.SoundTbl_Death = {"vj_hlr/th_npc/hunger/hungerzombie/zo_pain1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain3.wav"}
	end
	if self:GetModel() == "models/vj_hlr/theyhunger/zombie2_shotgunhead.mdl" then
	self.Zombie_Type = 11
	self.SoundTbl_Idle = {"vj_hlr/th_npc/hunger/hungerzombie/zo_idle1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle3.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle4.wav"}
	self.SoundTbl_CombatIdle = {"vj_hlr/th_npc/hunger/hungerzombie/zo_idle1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle3.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle4.wav"}
	self.SoundTbl_Alert = {"vj_hlr/th_npc/hunger/hungerzombie/zo_alert10.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_alert20.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_alert30.wav"}
	self.SoundTbl_BeforeMeleeAttack = {"vj_hlr/th_npc/hunger/hungerzombie/zo_attack1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_attack2.wav"}
	self.SoundTbl_MeleeAttackExtra = {"vj_hlr/hl1_npc/zombie/claw_strike1.wav","vj_hlr/hl1_npc/zombie/claw_strike2.wav","vj_hlr/hl1_npc/zombie/claw_strike3.wav"}
	self.SoundTbl_MeleeAttackMiss = {"vj_hlr/hl1_npc/zombie/claw_miss1.wav","vj_hlr/hl1_npc/zombie/claw_miss2.wav"}
	self.SoundTbl_Pain = {"vj_hlr/th_npc/hunger/hungerzombie/zo_pain1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain3.wav"}
	self.SoundTbl_Death = {"vj_hlr/th_npc/hunger/hungerzombie/zo_pain1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain3.wav"}
	end
	if self:GetModel() == "models/vj_hlr/theyhunger/zombie_preist.mdl" then
	self.Zombie_Type = 12
	self.SoundTbl_Idle = {"vj_hlr/th_npc/hunger/hungerzombie/zo_idle1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle3.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle4.wav"}
	self.SoundTbl_CombatIdle = {"vj_hlr/th_npc/hunger/hungerzombie/zo_idle1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle3.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle4.wav"}
	self.SoundTbl_Alert = {"vj_hlr/th_npc/hunger/hungerzombie/zo_alert10.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_alert20.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_alert30.wav"}
	self.SoundTbl_BeforeMeleeAttack = {"vj_hlr/th_npc/hunger/hungerzombie/zo_attack1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_attack2.wav"}
	self.SoundTbl_MeleeAttackExtra = {"vj_hlr/hl1_npc/zombie/claw_strike1.wav","vj_hlr/hl1_npc/zombie/claw_strike2.wav","vj_hlr/hl1_npc/zombie/claw_strike3.wav"}
	self.SoundTbl_MeleeAttackMiss = {"vj_hlr/hl1_npc/zombie/claw_miss1.wav","vj_hlr/hl1_npc/zombie/claw_miss2.wav"}
	self.SoundTbl_Pain = {"vj_hlr/th_npc/hunger/hungerzombie/zo_pain1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain3.wav"}
	self.SoundTbl_Death = {"vj_hlr/th_npc/hunger/hungerzombie/zo_pain1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain3.wav"}
	end
	if self:GetModel() == "models/vj_hlr/theyhunger/zombie_cleansuit.mdl" then
	self.Zombie_Type = 13
	self.SoundTbl_Idle = {"vj_hlr/th_npc/hunger/hungerzombie/zo_idle1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle3.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle4.wav"}
	self.SoundTbl_CombatIdle = {"vj_hlr/th_npc/hunger/hungerzombie/zo_idle1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle3.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle4.wav"}
	self.SoundTbl_Alert = {"vj_hlr/th_npc/hunger/hungerzombie/zo_alert10.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_alert20.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_alert30.wav"}
	self.SoundTbl_BeforeMeleeAttack = {"vj_hlr/th_npc/hunger/hungerzombie/zo_attack1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_attack2.wav"}
	self.SoundTbl_MeleeAttackExtra = {"vj_hlr/hl1_npc/zombie/claw_strike1.wav","vj_hlr/hl1_npc/zombie/claw_strike2.wav","vj_hlr/hl1_npc/zombie/claw_strike3.wav"}
	self.SoundTbl_MeleeAttackMiss = {"vj_hlr/hl1_npc/zombie/claw_miss1.wav","vj_hlr/hl1_npc/zombie/claw_miss2.wav"}
	self.SoundTbl_Pain = {"vj_hlr/th_npc/hunger/hungerzombie/zo_pain1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain3.wav"}
	self.SoundTbl_Death = {"vj_hlr/th_npc/hunger/hungerzombie/zo_pain1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain3.wav"}
	end
	if self:GetModel() == "models/vj_hlr/theyhunger/zombie_cleansuit.mdl" then
	self.Zombie_Type = 14
	self.SoundTbl_Idle = {"vj_hlr/th_npc/hunger/hungerzombie/zo_idle1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle3.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle4.wav"}
	self.SoundTbl_CombatIdle = {"vj_hlr/th_npc/hunger/hungerzombie/zo_idle1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle3.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle4.wav"}
	self.SoundTbl_Alert = {"vj_hlr/th_npc/hunger/hungerzombie/zo_alert10.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_alert20.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_alert30.wav"}
	self.SoundTbl_BeforeMeleeAttack = {"vj_hlr/th_npc/hunger/hungerzombie/zo_attack1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_attack2.wav"}
	self.SoundTbl_MeleeAttackExtra = {"vj_hlr/hl1_npc/zombie/claw_strike1.wav","vj_hlr/hl1_npc/zombie/claw_strike2.wav","vj_hlr/hl1_npc/zombie/claw_strike3.wav"}
	self.SoundTbl_MeleeAttackMiss = {"vj_hlr/hl1_npc/zombie/claw_miss1.wav","vj_hlr/hl1_npc/zombie/claw_miss2.wav"}
	self.SoundTbl_Pain = {"vj_hlr/th_npc/hunger/hungerzombie/zo_pain1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain3.wav"}
	self.SoundTbl_Death = {"vj_hlr/th_npc/hunger/hungerzombie/zo_pain1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain3.wav"}
	end
	if self:GetModel() == "models/vj_hlr/theyhunger/nursezombie.mdl" then
	self.AnimTbl_Run = {ACT_RUN}
	self.Zombie_Type = 15
	self.SoundTbl_Idle = {"vj_hlr/th_npc/hunger/znurse/zo_idle1.wav","vj_hlr/th_npc/hunger/znurse/zo_idle2.wav","vj_hlr/th_npc/hunger/znurse/zo_idle3.wav","vj_hlr/th_npc/hunger/znurse/zo_idle4.wav"}
	self.SoundTbl_CombatIdle = {"vj_hlr/th_npc/hunger/znurse/zo_idle1.wav","vj_hlr/th_npc/hunger/znurse/zo_idle2.wav","vj_hlr/th_npc/hunger/znurse/zo_idle3.wav","vj_hlr/th_npc/hunger/znurse/zo_idle4.wav"}
	self.SoundTbl_Alert = {"vj_hlr/th_npc/hunger/znurse/zo_alert10.wav","vj_hlr/th_npc/hunger/znurse/zo_alert20.wav","vj_hlr/th_npc/hunger/znurse/zo_alert30.wav"}
	self.SoundTbl_BeforeMeleeAttack = {"vj_hlr/th_npc/hunger/znurse/zo_attack1.wav","vj_hlr/th_npc/hunger/znurse/zo_attack2.wav"}
	self.SoundTbl_MeleeAttackExtra = {"vj_hlr/hl1_npc/zombie/claw_strike1.wav","vj_hlr/hl1_npc/zombie/claw_strike2.wav","vj_hlr/hl1_npc/zombie/claw_strike3.wav"}
	self.SoundTbl_MeleeAttackMiss = {"vj_hlr/hl1_npc/zombie/claw_miss1.wav","vj_hlr/hl1_npc/zombie/claw_miss2.wav"}
	self.SoundTbl_Pain = {"vj_hlr/th_npc/hunger/znurse/zo_pain1.wav","vj_hlr/th_npc/hunger/znurse/zo_pain2.wav"}
	self.SoundTbl_Death = {"vj_hlr/th_npc/hunger/znurse/scream1.wav","vj_hlr/th_npc/hunger/znurse/scream2.wav","vj_hlr/th_npc/hunger/znurse/scream3.wav"}
	end
	if self:GetModel() == "models/vj_hlr/theyhunger/zombie_doctor.mdl" then
	self.Zombie_Type = 16
	self.SoundTbl_Idle = {"vj_hlr/th_npc/hunger/hungerzombie/zo_idle1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle3.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle4.wav"}
	self.SoundTbl_CombatIdle = {"vj_hlr/th_npc/hunger/hungerzombie/zo_idle1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle3.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle4.wav"}
	self.SoundTbl_Alert = {"vj_hlr/th_npc/hunger/hungerzombie/zo_alert10.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_alert20.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_alert30.wav"}
	self.SoundTbl_BeforeMeleeAttack = {"vj_hlr/th_npc/hunger/hungerzombie/zo_attack1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_attack2.wav"}
	self.SoundTbl_MeleeAttackExtra = {"vj_hlr/hl1_npc/zombie/claw_strike1.wav","vj_hlr/hl1_npc/zombie/claw_strike2.wav","vj_hlr/hl1_npc/zombie/claw_strike3.wav"}
	self.SoundTbl_MeleeAttackMiss = {"vj_hlr/hl1_npc/zombie/claw_miss1.wav","vj_hlr/hl1_npc/zombie/claw_miss2.wav"}
	self.SoundTbl_Pain = {"vj_hlr/th_npc/hunger/hungerzombie/zo_pain1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain3.wav"}
	self.SoundTbl_Death = {"vj_hlr/th_npc/hunger/hungerzombie/zo_pain1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain3.wav"}
	end
	if self:GetModel() == "models/vj_hlr/theyhunger/zombie_patient.mdl" then
	self.Zombie_Type = 17
	self.SoundTbl_Idle = {"vj_hlr/th_npc/hunger/hungerzombie/zo_idle1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle3.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle4.wav"}
	self.SoundTbl_CombatIdle = {"vj_hlr/th_npc/hunger/hungerzombie/zo_idle1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle3.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle4.wav"}
	self.SoundTbl_Alert = {"vj_hlr/th_npc/hunger/hungerzombie/zo_alert10.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_alert20.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_alert30.wav"}
	self.SoundTbl_BeforeMeleeAttack = {"vj_hlr/th_npc/hunger/hungerzombie/zo_attack1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_attack2.wav"}
	self.SoundTbl_MeleeAttackExtra = {"vj_hlr/hl1_npc/zombie/claw_strike1.wav","vj_hlr/hl1_npc/zombie/claw_strike2.wav","vj_hlr/hl1_npc/zombie/claw_strike3.wav"}
	self.SoundTbl_MeleeAttackMiss = {"vj_hlr/hl1_npc/zombie/claw_miss1.wav","vj_hlr/hl1_npc/zombie/claw_miss2.wav"}
	self.SoundTbl_Pain = {"vj_hlr/th_npc/hunger/hungerzombie/zo_pain1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain3.wav"}
	self.SoundTbl_Death = {"vj_hlr/th_npc/hunger/hungerzombie/zo_pain1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain3.wav"}
	end
	if self:GetModel() == "models/vj_hlr/theyhunger/zombie_officer.mdl" then
	self.Zombie_Type = 18
	self.SoundTbl_Idle = {"vj_hlr/th_npc/hunger/hungerzombie/zo_idle1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle3.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle4.wav"}
	self.SoundTbl_CombatIdle = {"vj_hlr/th_npc/hunger/hungerzombie/zo_idle1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle3.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_idle4.wav"}
	self.SoundTbl_Alert = {"vj_hlr/th_npc/hunger/hungerzombie/zo_alert10.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_alert20.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_alert30.wav"}
	self.SoundTbl_BeforeMeleeAttack = {"vj_hlr/th_npc/hunger/hungerzombie/zo_attack1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_attack2.wav"}
	self.SoundTbl_MeleeAttackExtra = {"vj_hlr/hl1_npc/zombie/claw_strike1.wav","vj_hlr/hl1_npc/zombie/claw_strike2.wav","vj_hlr/hl1_npc/zombie/claw_strike3.wav"}
	self.SoundTbl_MeleeAttackMiss = {"vj_hlr/hl1_npc/zombie/claw_miss1.wav","vj_hlr/hl1_npc/zombie/claw_miss2.wav"}
	self.SoundTbl_Pain = {"vj_hlr/th_npc/hunger/hungerzombie/zo_pain1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain3.wav"}
	self.SoundTbl_Death = {"vj_hlr/th_npc/hunger/hungerzombie/zo_pain1.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain2.wav","vj_hlr/th_npc/hunger/hungerzombie/zo_pain3.wav"}
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnPriorToKilled(dmginfo,hitgroup)
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnThink()
	self:StopSound("common/npc_step1.wav")
	self:StopSound("common/npc_step2.wav")
	self:StopSound("common/npc_step3.wav")
	self:StopSound("common/npc_step4.wav")
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnAcceptInput(key, activator, caller, data)
	//print(key)
	if key == "event_emit step" then
		self:FootStepSoundCode()
	end
	if key == "event_mattack right" or key == "event_mattack left" or key == "event_mattack both" then
		self:MeleeAttackCode()
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:MultipleMeleeAttacks()
	if math.random(1,2) == 1 then
		self.TimeUntilMeleeAttackDamage = 0.7 -- This counted in seconds | This calculates the time until it hits something
		self.MeleeAttackExtraTimers = {1.4} -- Extra leap attack timers | it will run the damage code after the given amount of seconds
		self.AnimTbl_MeleeAttack = {"vjseq_attack1"}
		self.MeleeAttackDamage = 10
	else
		self.MeleeAttackExtraTimers = {} -- Extra leap attack timers | it will run the damage code after the given amount of seconds
		self.TimeUntilMeleeAttackDamage = 0.4 -- This counted in seconds | This calculates the time until it hits something
		self.AnimTbl_MeleeAttack = {"vjseq_attack2"}
		self.MeleeAttackDamage = 20
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:SetUpGibesOnDeath(dmginfo,hitgroup)
	self.HasDeathSounds = false
	if self.HasGibDeathParticles == true then
		local bloodeffect = EffectData()
		bloodeffect:SetOrigin(self:GetPos() +self:OBBCenter())
		bloodeffect:SetColor(VJ_Color2Byte(Color(130,19,10)))
		bloodeffect:SetScale(120)
		util.Effect("VJ_Blood1",bloodeffect)
		
		local bloodspray = EffectData()
		bloodspray:SetOrigin(self:GetPos())
		bloodspray:SetScale(8)
		bloodspray:SetFlags(3)
		bloodspray:SetColor(0)
		util.Effect("bloodspray",bloodspray)
		util.Effect("bloodspray",bloodspray)
	end
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/flesh1.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,40))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/flesh2.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,40))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/flesh3.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,40))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/flesh4.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,40))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/hgib_b_bone.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,50))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/hgib_b_gib.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,40))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/hgib_guts.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,40))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/hgib_hmeat.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,45))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/hgib_lung.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,45))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/hgib_skull.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,60))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/hgib_legbone.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,15))})
	return true -- Return to true if it gibbed!
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomGibOnDeathSounds(dmginfo,hitgroup)
	VJ_EmitSound(self, "vj_gib/default_gib_splat.wav", 90, math.random(100,100))
	return false
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnTakeDamage_BeforeImmuneChecks(dmginfo,hitgroup)
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomDeathAnimationCode(dmginfo,hitgroup)
	if hitgroup == HITGROUP_HEAD then
		self.AnimTbl_Death = {ACT_DIE_GUTSHOT,ACT_DIE_HEADSHOT}
	else
		self.AnimTbl_Death = {ACT_DIEBACKWARD,ACT_DIEFORWARD,ACT_DIESIMPLE}
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnDeath_AfterCorpseSpawned(dmginfo,hitgroup)
	self.Corpse:RemoveAllDecals()
	self.Corpse:DrawShadow(false)
	self.Corpse:SetMaterial("Invisible")
	if self.Zombie_Type == 1 then
	self.PropGun = ents.Create("obj_warlord_gun")
	self.PropGun:SetModel("models/vj_hlr/theyhunger/zombie_glasseye.mdl")
	self.PropGun:Spawn()
	self.PropGun:SetParent(self.Corpse)
	self.PropGun:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
	end
	if self.Zombie_Type == 2 then
	self.PropGun = ents.Create("obj_warlord_gun")
	self.PropGun:SetModel("models/vj_hlr/theyhunger/zombie_woman.mdl")
	self.PropGun:Spawn()
	self.PropGun:SetParent(self.Corpse)
	self.PropGun:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
	end
	if self.Zombie_Type == 3 then
	self.PropGun = ents.Create("obj_warlord_gun")
	self.PropGun:SetModel("models/vj_hlr/theyhunger/zombie_normal.mdl")
	self.PropGun:Spawn()
	self.PropGun:SetParent(self.Corpse)
	self.PropGun:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
	end
	if self.Zombie_Type == 4 then
	self.PropGun = ents.Create("obj_warlord_gun")
	self.PropGun:SetModel("models/vj_hlr/theyhunger/zombie_headless1.mdl")
	self.PropGun:Spawn()
	self.PropGun:SetParent(self.Corpse)
	self.PropGun:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
	end
	if self.Zombie_Type == 5 then
	self.PropGun = ents.Create("obj_warlord_gun")
	self.PropGun:SetModel("models/vj_hlr/theyhunger/zombie_cop.mdl")
	self.PropGun:Spawn()
	self.PropGun:SetParent(self.Corpse)
	self.PropGun:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
	end
	if self.Zombie_Type == 6 then
	self.PropGun = ents.Create("obj_warlord_gun")
	self.PropGun:SetModel("models/vj_hlr/theyhunger/zombie2_nofacecop.mdl")
	self.PropGun:Spawn()
	self.PropGun:SetParent(self.Corpse)
	self.PropGun:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
	end
	if self.Zombie_Type == 7 then
	self.PropGun = ents.Create("obj_warlord_gun")
	self.PropGun:SetModel("models/vj_hlr/theyhunger/zombie2_crowbarcop.mdl")
	self.PropGun:Spawn()
	self.PropGun:SetParent(self.Corpse)
	self.PropGun:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
	end
	if self.Zombie_Type == 8 then
	self.PropGun = ents.Create("obj_warlord_gun")
	self.PropGun:SetModel("models/vj_hlr/theyhunger/zombie2_coolzombie.mdl")
	self.PropGun:Spawn()
	self.PropGun:SetParent(self.Corpse)
	self.PropGun:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
	end
	if self.Zombie_Type == 9 then
	self.PropGun = ents.Create("obj_warlord_gun")
	self.PropGun:SetModel("models/vj_hlr/theyhunger/zombie2_chefknife.mdl")
	self.PropGun:Spawn()
	self.PropGun:SetParent(self.Corpse)
	self.PropGun:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
	end
	if self.Zombie_Type == 10 then
	self.PropGun = ents.Create("obj_warlord_gun")
	self.PropGun:SetModel("models/vj_hlr/theyhunger/zombie2_cleverguy.mdl")
	self.PropGun:Spawn()
	self.PropGun:SetParent(self.Corpse)
	self.PropGun:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
	end
	if self.Zombie_Type == 11 then
	self.PropGun = ents.Create("obj_warlord_gun")
	self.PropGun:SetModel("models/vj_hlr/theyhunger/zombie2_shotgunhead.mdl")
	self.PropGun:Spawn()
	self.PropGun:SetParent(self.Corpse)
	self.PropGun:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
	end
	if self.Zombie_Type == 12 then
	self.PropGun = ents.Create("obj_warlord_gun")
	self.PropGun:SetModel("models/vj_hlr/theyhunger/zombie_preist.mdl")
	self.PropGun:Spawn()
	self.PropGun:SetParent(self.Corpse)
	self.PropGun:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
	end
	if self.Zombie_Type == 13 then
	self.PropGun = ents.Create("obj_warlord_gun")
	self.PropGun:SetModel("models/vj_hlr/theyhunger/zombie_cleansuit.mdl")
	self.PropGun:Spawn()
	self.PropGun:SetParent(self.Corpse)
	self.PropGun:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
	end
	if self.Zombie_Type == 14 then
	self.PropGun = ents.Create("obj_warlord_gun")
	self.PropGun:SetModel("models/vj_hlr/theyhunger/zombie_fire.mdl")
	self.PropGun:Spawn()
	self.PropGun:SetParent(self.Corpse)
	self.PropGun:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
	end
	if self.Zombie_Type == 15 then
	self.PropGun = ents.Create("obj_warlord_gun")
	self.PropGun:SetModel("models/vj_hlr/theyhunger/nursezombie.mdl")
	self.PropGun:Spawn()
	self.PropGun:SetParent(self.Corpse)
	self.PropGun:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
	end
	if self.Zombie_Type == 16 then
	self.PropGun = ents.Create("obj_warlord_gun")
	self.PropGun:SetModel("models/vj_hlr/theyhunger/zombie_doctor.mdl")
	self.PropGun:Spawn()
	self.PropGun:SetParent(self.Corpse)
	self.PropGun:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
	end
	if self.Zombie_Type == 17 then
	self.PropGun = ents.Create("obj_warlord_gun")
	self.PropGun:SetModel("models/vj_hlr/theyhunger/zombie_patient.mdl")
	self.PropGun:Spawn()
	self.PropGun:SetParent(self.Corpse)
	self.PropGun:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
	end
	if self.Zombie_Type == 18 then
	self.PropGun = ents.Create("obj_warlord_gun")
	self.PropGun:SetModel("models/vj_hlr/theyhunger/zombie_officer.mdl")
	self.PropGun:Spawn()
	self.PropGun:SetParent(self.Corpse)
	self.PropGun:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
	end
end
/*-----------------------------------------------
	*** Copyright (c) 2012-2020 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/