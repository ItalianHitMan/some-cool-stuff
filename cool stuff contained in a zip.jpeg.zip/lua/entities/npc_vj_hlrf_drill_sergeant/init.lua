AddCSLuaFile("shared.lua")
include('shared.lua')
/*-----------------------------------------------
	*** Copyright (c) 2012-2020 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/
ENT.Model = {"models/drillin/drill_opf.mdl"} -- The game will pick a random model from the table when the SNPC is spawned | Add as many as you want
ENT.StartHealth = 60
ENT.HullType = HULL_HUMAN
ENT.VJC_Data = {
    ThirdP_Offset = Vector(10, 0, -30), -- The offset for the controller when the camera is in third person
    FirstP_Bone = "Bip01 Head", -- If left empty, the base will attempt to calculate a position for first person
    FirstP_Offset = Vector(5, 0, 5), -- The offset for the controller when the camera is in first person
}
---------------------------------------------------------------------------------------------------------------------------------------------
ENT.VJ_NPC_Class = {"CLASS_PLAYER_ALLY"} -- NPCs with the same class with be allied to each other
ENT.FriendsWithAllPlayerAllies = true -- Should this SNPC be friends with all other player allies that are running on VJ Base?
ENT.BloodColor = "Red" -- The blood type, this will determine what it should use (decal, particle, etc.)
ENT.CustomBlood_Particle = {"vj_hl_blood_red"}
ENT.CustomBlood_Decal = {"VJ_HLR_Blood_Red"} -- Decals to spawn when it's damaged
ENT.HasBloodPool = false -- Does it have a blood pool?
ENT.Behavior = VJ_BEHAVIOR_PASSIVE -- Doesn't attack anything
ENT.HasItemDropsOnDeath = false -- Should it drop items on death?
ENT.HasMeleeAttack = false -- Should the SNPC have a melee attack?
ENT.DisableFootStepSoundTimer = true -- If set to true, it will disable the time system for the footstep sound code, allowing you to use other ways like model events
ENT.IsMedicSNPC = false -- Is this SNPC a medic? Does it heal other friendly friendly SNPCs, and players(If friendly)
ENT.Medic_DisableAnimation = true -- if true, it will disable the animation code
ENT.Medic_TimeUntilHeal = 4 -- Time until the ally receives health | Set to false to let the base decide the time
ENT.Medic_SpawnPropOnHeal = false -- Should it spawn a prop, such as small health vial at a attachment when healing an ally?
ENT.HasDeathAnimation = true -- Does it play an animation when it dies?
ENT.AnimTbl_Death = {"vjseq_diebackward","vjseq_dieforward","vjseq_diesimple"} -- Death Animations
ENT.DeathAnimationTime = false -- Time until the SNPC spawns its corpse and gets removed
ENT.CombatFaceEnemy = false -- If enemy is exists and is visible
ENT.HasIdleDialogueSounds = false -- If set to false, it won't play the idle dialogue sounds
ENT.HasIdleDialogueAnswerSounds = false -- If set to false, it won't play the idle dialogue answer sounds
ENT.IdleDialogueDistance = 0 -- How close should the ally be for the SNPC to talk to the ally?
ENT.IdleDialogueCanTurn = false -- If set to false, it won't turn when a dialogue occurs
ENT.DeathCorpseModel = {"models/half life rebuilt (cad)/cad_gus.mdl"}
	-- ====== Flinching Variables ====== --
ENT.CanFlinch = 1 -- 0 = Don't flinch | 1 = Flinch at any damage | 2 = Flinch only from certain damages
ENT.AnimTbl_Flinch = {ACT_SMALL_FLINCH} -- If it uses normal based animation, use this
ENT.HasHitGroupFlinching = true -- It will flinch when hit in certain hitgroups | It can also have certain animations to play in certain hitgroups
ENT.HitGroupFlinching_Values = {{HitGroup = {HITGROUP_LEFTLEG}, Animation = {ACT_FLINCH_LEFTLEG}},{HitGroup = {HITGROUP_RIGHTLEG}, Animation = {ACT_FLINCH_RIGHTLEG}}}
	-- ====== File Path Variables ====== --
	-- Leave blank if you don't want any sounds to play
ENT.SoundTbl_FootStep = {"vj_hlr/pl_step1.wav","vj_hlr/pl_step2.wav","vj_hlr/pl_step3.wav","vj_hlr/pl_step4.wav"}

/*
-- Can't move, unfollow
"vj_hlr/hl1_npc/scientist/dangerous.wav"
vj_hlr/hl1_npc/scientist/stop1.wav
vj_hlr/hl1_npc/scientist/stop2.wav
vj_hlr/hl1_npc/scientist/stop3.wav
vj_hlr/hl1_npc/scientist/stop4.wav

"vj_hlr/hl1_npc/scientist/limitsok.wav",

vj_hlr/hl1_npc/scientist/assist.wav
vj_hlr/hl1_npc/scientist/b01_sci02_briefcase.wav
vj_hlr/hl1_npc/scientist/b01_sci03_sirplease.wav
vj_hlr/hl1_npc/scientist/c1a0_sci_catscream.wav
vj_hlr/hl1_npc/scientist/c1a0_sci_crit1a.wav
vj_hlr/hl1_npc/scientist/c1a0_sci_crit2a.wav
vj_hlr/hl1_npc/scientist/c1a0_sci_crit3a.wav
vj_hlr/hl1_npc/scientist/c1a0_sci_ctrl1a.wav
vj_hlr/hl1_npc/scientist/c1a0_sci_ctrl2a.wav
vj_hlr/hl1_npc/scientist/c1a0_sci_ctrl3a.wav
-- vj_hlr/hl1_npc/scientist/c1a0_sci_dis10a.wav ----> vj_hlr/hl1_npc/scientist/c1a0_sci_disa.wav
vj_hlr/hl1_npc/scientist/c1a0_sci_getaway.wav
-- vj_hlr/hl1_npc/scientist/c1a0_sci_lock1a.wav ----> vj_hlr/hl1_npc/scientist/c1a0_sci_lock8a.wav
vj_hlr/hl1_npc/scientist/c1a0_sci_mumble.wav
vj_hlr/hl1_npc/scientist/c1a0_sci_samp.wav
vj_hlr/hl1_npc/scientist/c1a1_sci_4scan.wav
vj_hlr/hl1_npc/scientist/c1a2_sci_6zomb.wav
vj_hlr/hl1_npc/scientist/c1a2_sci_elevator.wav
vj_hlr/hl1_npc/scientist/c1a2_sci_lounge.wav
vj_hlr/hl1_npc/scientist/c1a2_sci_transm.wav
vj_hlr/hl1_npc/scientist/c1a3_sci_atlast.wav
vj_hlr/hl1_npc/scientist/c1a3_sci_rescued.wav
vj_hlr/hl1_npc/scientist/c1a3_sci_silo1a.wav
vj_hlr/hl1_npc/scientist/c1a4_sci_blind.wav
vj_hlr/hl1_npc/scientist/c1a4_sci_gener.wav
vj_hlr/hl1_npc/scientist/c1a4_sci_pwr.wav
vj_hlr/hl1_npc/scientist/c1a4_sci_rocket.wav
vj_hlr/hl1_npc/scientist/c1a4_sci_tent.wav
vj_hlr/hl1_npc/scientist/c1a4_sci_trust.wav
"vj_hlr/hl1_npc/scientist/c1a4_sci_pwroff.wav",
"vj_hlr/hl1_npc/scientist/c1a2_sci_darkroom.wav",
vj_hlr/hl1_npc/scientist/c2a3_sci_icky.wav
vj_hlr/hl1_npc/scientist/c2a3_sci_track.wav
vj_hlr/hl1_npc/scientist/c2a4_sci_2tau.wav
vj_hlr/hl1_npc/scientist/c2a4_sci_4tau.wav
vj_hlr/hl1_npc/scientist/c2a4_sci_letout.wav
vj_hlr/hl1_npc/scientist/c2a4_sci_scanner.wav
vj_hlr/hl1_npc/scientist/c2a4_sci_sugicaloff.wav
"vj_hlr/hl1_npc/scientist/c2a4_sci_arg2a.wav",
"vj_hlr/hl1_npc/scientist/c2a4_sci_arg4a.wav",
vj_hlr/hl1_npc/scientist/c2a5_sci_boobie.wav
vj_hlr/hl1_npc/scientist/c2a5_sci_lebuz.wav
vj_hlr/hl1_npc/scientist/c3a1_sci_2sat.wav
vj_hlr/hl1_npc/scientist/c3a1_sci_4sat.wav
vj_hlr/hl1_npc/scientist/c3a1_sci_6sat.wav
vj_hlr/hl1_npc/scientist/c3a1_sci_dome.wav
vj_hlr/hl1_npc/scientist/c3a1_sci_done.wav
vj_hlr/hl1_npc/scientist/c3a2_sci_2glu.wav
vj_hlr/hl1_npc/scientist/c3a2_sci_3glu.wav
vj_hlr/hl1_npc/scientist/c3a2_sci_3surv.wav
vj_hlr/hl1_npc/scientist/c3a2_sci_5surv.wav
vj_hlr/hl1_npc/scientist/c3a2_sci_7surv.wav
vj_hlr/hl1_npc/scientist/c3a2_sci_flood.wav
vj_hlr/hl1_npc/scientist/c3a2_sci_forever.wav
vj_hlr/hl1_npc/scientist/c3a2_sci_linger.wav
vj_hlr/hl1_npc/scientist/c3a2_sci_ljump.wav
-- vj_hlr/hl1_npc/scientist/c3a2_sci_notyet.wav ----> vj_hlr/hl1_npc/scientist/c3a2_sci_uphere_alt.wav
vj_hlr/hl1_npc/scientist/crossgreen.wav
-- vj_hlr/hl1_npc/scientist/d01_sci01_waiting.wav ----> vj_hlr/hl1_npc/scientist/d01_sci09_pushsample2.wav
-- vj_hlr/hl1_npc/scientist/d01_sci11_shouldnthappen.wav ----> vj_hlr/hl1_npc/scientist/d01_sci13_jammed.wav
-- vj_hlr/hl1_npc/scientist/d01_sci15_onschedule.wav ----> vj_hlr/hl1_npc/scientist/d08_sci05_osprey.wav
vj_hlr/hl1_npc/scientist/dontgothere.wav
vj_hlr/hl1_npc/scientist/forcefield_b.wav
vj_hlr/hl1_npc/scientist/g_bounce1.wav
vj_hlr/hl1_npc/scientist/helloladies.wav
vj_hlr/hl1_npc/scientist/letyouin.wav
-- vj_hlr/hl1_npc/scientist/of1a1_sc01.wav ----> vj_hlr/hl1_npc/scientist/of4a1_sc01.wav
vj_hlr/hl1_npc/scientist/perfume.wav
-- vj_hlr/hl1_npc/scientist/sci_1thou.wav ----> vj_hlr/hl1_npc/scientist/sci_5thou.wav
vj_hlr/hl1_npc/scientist/sci_aftertest.wav
vj_hlr/hl1_npc/scientist/sci_alone.wav
vj_hlr/hl1_npc/scientist/sci_busy.wav
vj_hlr/hl1_npc/scientist/shesgonemad.wav
vj_hlr/hl1_npc/scientist/spinals.wav
vj_hlr/hl1_npc/scientist/tram.wav
vj_hlr/hl1_npc/scientist/underbarrel.wav
vj_hlr/hl1_npc/scientist/ushouldsee.wav
vj_hlr/hl1_npc/scientist/whoareyou.wav
vj_hlr/hl1_npc/scientist/xena.wav
vj_hlr/hl1_npc/scientist/scream7.wav (duplicate of scream6)
*/

ENT.GeneralSoundPitch1 = 100

-- Custom
ENT.SCI_NextMouthMove = 0
ENT.SCI_NextMouthDistance = 0
ENT.SCI_Type = 0
ENT.Barnes = false
ENT.Sharp = false
	-- 0 = Regular Scientist and Dr. Rosenberg
	-- 1 = Cleansuit Scientist
	-- 2 = Dr. Keller
	-- 3 = Alpha Scientist
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnInitialize()
	if self:GetModel() == "models/vj_hlr/hl1/scientist.mdl" then
		self.SCI_Type = 0
	elseif self:GetModel() == "models/vj_hlr/opfor/cleansuit_scientist.mdl" then
		self.SCI_Type = 1
	elseif self:GetModel() == "models/vj_hlr/decay/wheelchair_sci.mdl" then
		self.SCI_Type = 2
	elseif self:GetModel() == "models/vj_hlr/hla/scientist.mdl" then
		self.SCI_Type = 3
	end
	self:SCI_CustomOnInitialize()
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:SCI_CustomOnInitialize()
	self:SetSubMaterial(1 ,"spazter/paint_colors/chrome/australium_gold")
	self:SetSubMaterial(4 ,"models/chrome/agrunt/chrome2")
	self.SoundTbl_CombatIdle = {"vj_hlr/hl1_npc/drill/oc106d.wav","vj_hlr/hl1_npc/drill/livefire07.wav","vj_hlr/hl1_npc/drill/dr2_add10.wav","vj_hlr/hl1_npc/drill/dr2_add01.wav","vj_hlr/hl1_npc/drill/dr2_add17.wav","vj_hlr/hl1_npc/drill/dr2_add06.wav"}
	self.SoundTbl_Alert = {"vj_hlr/hl1_npc/drill/oc101.wav","vj_hlr/hl1_npc/drill/livefire09.wav","vj_hlr/hl1_npc/drill/livefire05.wav","vj_hlr/hl1_npc/drill/livefire06.wav","vj_hlr/hl1_npc/drill/dr2_add18.wav","vj_hlr/hl1_npc/drill/dr2_add04.wav"}
	self.SoundTbl_FollowPlayer = {"vj_hlr/hl1_npc/drill/dr2_add01.wav","vj_hlr/hl1_npc/drill/dr2_add02.wav","vj_hlr/hl1_npc/drill/dr2_add03.wav","vj_hlr/hl1_npc/drill/dr2_add04.wav","vj_hlr/hl1_npc/drill/dr2_add05.wav","vj_hlr/hl1_npc/drill/dr2_add06.wav","vj_hlr/hl1_npc/drill/dr2_add07.wav","vj_hlr/hl1_npc/drill/dr2_add08.wav","vj_hlr/hl1_npc/drill/dr2_add09.wav","vj_hlr/hl1_npc/drill/dr2_add10.wav","vj_hlr/hl1_npc/drill/dr2_add11.wav","vj_hlr/hl1_npc/drill/dr2_add13.wav","vj_hlr/hl1_npc/drill/dr2_add14.wav","vj_hlr/hl1_npc/drill/dr2_add15.wav","vj_hlr/hl1_npc/drill/dr2_add16.wav","vj_hlr/hl1_npc/drill/dr2_add17.wav","vj_hlr/hl1_npc/drill/dr2_add18.wav","vj_hlr/hl1_npc/drill/dr2_add19.wav"}
	self.SoundTbl_UnFollowPlayer = {"vj_hlr/hl1_npc/drill/dr2_add01.wav","vj_hlr/hl1_npc/drill/dr2_add02.wav","vj_hlr/hl1_npc/drill/dr2_add03.wav","vj_hlr/hl1_npc/drill/dr2_add04.wav","vj_hlr/hl1_npc/drill/dr2_add05.wav","vj_hlr/hl1_npc/drill/dr2_add06.wav","vj_hlr/hl1_npc/drill/dr2_add07.wav","vj_hlr/hl1_npc/drill/dr2_add08.wav","vj_hlr/hl1_npc/drill/dr2_add09.wav","vj_hlr/hl1_npc/drill/dr2_add10.wav","vj_hlr/hl1_npc/drill/dr2_add11.wav","vj_hlr/hl1_npc/drill/dr2_add13.wav","vj_hlr/hl1_npc/drill/dr2_add14.wav","vj_hlr/hl1_npc/drill/dr2_add15.wav","vj_hlr/hl1_npc/drill/dr2_add16.wav","vj_hlr/hl1_npc/drill/dr2_add17.wav","vj_hlr/hl1_npc/drill/dr2_add18.wav","vj_hlr/hl1_npc/drill/dr2_add19.wav"}
	self.SoundTbl_OnGrenadeSight = {"vj_hlr/hl1_npc/drill/livefire04.wav","vj_hlr/hl1_npc/drill/livefire07.wav","vj_hlr/hl1_npc/drill/livefire09.wav"}
	self.SoundTbl_AllyDeath = {"vj_hlr/hl1_npc/drill/livefire08.wav","vj_hlr/hl1_npc/drill/oc108.wav"}
	self.SoundTbl_Pain = {"vj_hlr/hl1_npc/hgrunt_oppf/gr_pain1.wav","vj_hlr/hl1_npc/hgrunt_oppf/gr_pain2.wav","vj_hlr/hl1_npc/hgrunt_oppf/gr_pain3.wav","vj_hlr/hl1_npc/hgrunt_oppf/gr_pain4.wav","vj_hlr/hl1_npc/hgrunt_oppf/gr_pain5.wav","vj_hlr/hl1_npc/hgrunt_oppf/gr_pain6.wav"}
	self.SoundTbl_Death = {"vj_hlr/hl1_npc/hgrunt_oppf/death1.wav","vj_hlr/hl1_npc/hgrunt_oppf/death2.wav","vj_hlr/hl1_npc/hgrunt_oppf/death3.wav","vj_hlr/hl1_npc/hgrunt_oppf/death4.wav","vj_hlr/hl1_npc/hgrunt_oppf/death5.wav","vj_hlr/hl1_npc/hgrunt_oppf/death6.wav"}
	
	local randbg = math.random(1,3)
	if randbg == 1 then
		self.Sharp = true
		self:SetSkin(0)
	end
	if randbg == 2 then
		self.Barnes = true
		self:SetSkin(1)
	end
	if randbg == 3 then
		self.Sharp = true
		self:SetSkin(0)
	end
	//self:VJ_GetAllPoseParameters(true)
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnAcceptInput(key, activator, caller, data)
	//print(key)
	if key == "step" or key == "wheelchair" then
		self:FootStepSoundCode()
	end
	if key == "tie" then
		self:StopAllCommonSpeechSounds()
		VJ_EmitSound(self,{"vj_hlr/hl1_npc/scientist/weartie.wav","vj_hlr/hl1_npc/scientist/ties.wav"},80,100)
	end
	if key == "draw" then
		self:SetBodygroup(2,1)
	end
	if key == "holster" then
		self:SetBodygroup(2,0)
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnMedic_BeforeHeal()
	self:VJ_ACT_PLAYACTIVITY("pull_needle",true,VJ_GetSequenceDuration(self,"pull_needle") + 0.1,false,0,{},function(vsched)
		vsched.RunCode_OnFinish = function()
			self:VJ_ACT_PLAYACTIVITY("give_shot",true,VJ_GetSequenceDuration(self,"give_shot") + 0.1,false,0,{},function(vsched2)
				vsched2.RunCode_OnFinish = function()
					self:VJ_ACT_PLAYACTIVITY("return_needle",true,false)
				end
			end)
		end
	end)
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnMedic_OnReset()
	timer.Simple(1.5,function() if IsValid(self) then self:SetBodygroup(2,0) end end)
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnAlert(argent)
	if self.SCI_Type != 2 && self.SCI_Type != 3 then
		if math.random(1,2) == 1 && argent.HLR_Type == "Headcrab" or argent:GetClass() == "npc_headcrab" or argent:GetClass() == "npc_headcrab_black" or argent:GetClass() == "npc_headcrab_fast" then
			self:PlaySoundSystem("Alert", {"vj_hlr/hl1_npc/scientist/seeheadcrab.wav"})
			self.NextAlertSoundT = CurTime() + math.Rand(self.NextSoundTime_Alert1,self.NextSoundTime_Alert2)
		end
		if argent:GetPos():Distance(self:GetPos()) >= 300 && math.random(1,2) == 1 then
			self:VJ_ACT_PLAYACTIVITY({"vjseq_eye_wipe","vjseq_fear1","vjseq_fear2"}, true, false, true)
		end
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnThink()
	if IsValid(self:GetEnemy()) && self.SCI_Type != 3 then
		self.AnimTbl_ScaredBehaviorStand = {ACT_IDLE}
		self.AnimTbl_IdleStand = {ACT_IDLE}
		if self.SCI_Type != 2 then
			self.AnimTbl_Walk = {ACT_WALK}
		end
		self.AnimTbl_Run = {ACT_RUN}
	else
		if math.random(1,25) == 1 && self.SCI_Type == 1 then
			self.AnimTbl_IdleStand = {ACT_IDLE}
		else
			self.AnimTbl_IdleStand = {ACT_IDLE}
		end
		self.AnimTbl_Walk = {ACT_WALK}
		self.AnimTbl_Run = {ACT_RUN}
	end
	
	if self.SCI_Type == 2 && self:GetBodygroup(0) == 1 then
		self.HasDeathAnimation = false
		self:TakeDamage(999999999,self,self)
	end
	
	if CurTime() < self.SCI_NextMouthMove then
		if self.SCI_NextMouthDistance == 0 then
			self.SCI_NextMouthDistance = math.random(10,70)
		else
			self.SCI_NextMouthDistance = 0
		end
		self:SetPoseParameter("m",self.SCI_NextMouthDistance)
	else
		self:SetPoseParameter("m",0)
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:OnPlayCreateSound(SoundData,SoundFile)
	self.SCI_NextMouthMove = CurTime() + SoundDuration(SoundFile)
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnPriorToKilled(dmginfo,hitgroup)
	self:SetBodygroup(2,0)
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:SetUpGibesOnDeath(dmginfo,hitgroup)
	self.HasDeathSounds = false
	if self.HasGibDeathParticles == true then
		local bloodeffect = EffectData()
		bloodeffect:SetOrigin(self:GetPos() +self:OBBCenter())
		bloodeffect:SetColor(VJ_Color2Byte(Color(130,19,10)))
		bloodeffect:SetScale(120)
		util.Effect("VJ_Blood1",bloodeffect)
		
		local bloodspray = EffectData()
		bloodspray:SetOrigin(self:GetPos())
		bloodspray:SetScale(8)
		bloodspray:SetFlags(3)
		bloodspray:SetColor(0)
		util.Effect("bloodspray",bloodspray)
		util.Effect("bloodspray",bloodspray)
		
		if self.SCI_Type == 2 then
			local effectdata = EffectData()
			effectdata:SetOrigin(self:GetPos())
			util.Effect("HelicopterMegaBomb", effectdata)
			ParticleEffect("explosion_turret_break_fire", self:GetPos() +self:GetUp() *30, Angle(0,0,0))
		end
	end
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/flesh1.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,40))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/flesh2.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,40))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/flesh3.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,40))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/flesh4.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,40))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/hgib_b_bone.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,50))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/hgib_b_gib.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,40))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/hgib_guts.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,40))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/hgib_hmeat.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,45))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/hgib_lung.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,45))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/hgib_skull.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,60))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/hgib_legbone.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,15))})
	if self.SCI_Type == 2 then
		self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/wheelchair_seat.mdl",{BloodDecal="",Pos=self:LocalToWorld(Vector(0,0,20)),Ang=self:LocalToWorldAngles(Angle(0,-10,0)),CollideSound={"vj_hlr/fx/metal1.wav","vj_hlr/fx/metal2.wav","vj_hlr/fx/metal3.wav","vj_hlr/fx/metal4.wav","vj_hlr/fx/metal5.wav"}})
		self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/wheelchair_back.mdl",{BloodDecal="",Pos=self:LocalToWorld(Vector(-15,0,35)),Ang=self:LocalToWorldAngles(Angle(0,-10,0)),CollideSound={"vj_hlr/fx/metal1.wav","vj_hlr/fx/metal2.wav","vj_hlr/fx/metal3.wav","vj_hlr/fx/metal4.wav","vj_hlr/fx/metal5.wav"}})
		self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/wheelchair_headrest.mdl",{BloodDecal="",Pos=self:LocalToWorld(Vector(-15,0,55)),Ang=self:LocalToWorldAngles(Angle(0,-10,0)),CollideSound={"vj_hlr/fx/metal1.wav","vj_hlr/fx/metal2.wav","vj_hlr/fx/metal3.wav","vj_hlr/fx/metal4.wav","vj_hlr/fx/metal5.wav"}})
		self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/wheelchair_arm.mdl",{BloodDecal="",Pos=self:LocalToWorld(Vector(0,-15,32)),Ang=self:LocalToWorldAngles(Angle(0,-10,0)),CollideSound={"vj_hlr/fx/metal1.wav","vj_hlr/fx/metal2.wav","vj_hlr/fx/metal3.wav","vj_hlr/fx/metal4.wav","vj_hlr/fx/metal5.wav"}})
		self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/wheelchair_arm.mdl",{BloodDecal="",Pos=self:LocalToWorld(Vector(0,15,32)),Ang=self:LocalToWorldAngles(Angle(0,-10,0)),CollideSound={"vj_hlr/fx/metal1.wav","vj_hlr/fx/metal2.wav","vj_hlr/fx/metal3.wav","vj_hlr/fx/metal4.wav","vj_hlr/fx/metal5.wav"}})
		self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/wheelchair_backwheel.mdl",{BloodDecal="",Pos=self:LocalToWorld(Vector(-15,-15,5)),Ang=self:LocalToWorldAngles(Angle(0,0,0)),CollideSound={"vj_hlr/fx/metal1.wav","vj_hlr/fx/metal2.wav","vj_hlr/fx/metal3.wav","vj_hlr/fx/metal4.wav","vj_hlr/fx/metal5.wav"}})
		self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/wheelchair_backwheel.mdl",{BloodDecal="",Pos=self:LocalToWorld(Vector(-15,15,5)),Ang=self:LocalToWorldAngles(Angle(0,0,0)),CollideSound={"vj_hlr/fx/metal1.wav","vj_hlr/fx/metal2.wav","vj_hlr/fx/metal3.wav","vj_hlr/fx/metal4.wav","vj_hlr/fx/metal5.wav"}})
		self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/wheelchair_frontwheel.mdl",{BloodDecal="",Pos=self:LocalToWorld(Vector(15,-15,5)),Ang=self:LocalToWorldAngles(Angle(0,90,0)),CollideSound={"vj_hlr/fx/metal1.wav","vj_hlr/fx/metal2.wav","vj_hlr/fx/metal3.wav","vj_hlr/fx/metal4.wav","vj_hlr/fx/metal5.wav"}})
		self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/wheelchair_frontwheel.mdl",{BloodDecal="",Pos=self:LocalToWorld(Vector(15,15,5)),Ang=self:LocalToWorldAngles(Angle(0,90,0)),CollideSound={"vj_hlr/fx/metal1.wav","vj_hlr/fx/metal2.wav","vj_hlr/fx/metal3.wav","vj_hlr/fx/metal4.wav","vj_hlr/fx/metal5.wav"}})
		self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/rgib_screw.mdl",{BloodDecal="",Pos=self:LocalToWorld(Vector(0,0,20)),CollideSound={"vj_hlr/fx/metal1.wav","vj_hlr/fx/metal2.wav","vj_hlr/fx/metal3.wav","vj_hlr/fx/metal4.wav","vj_hlr/fx/metal5.wav"}})
		self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/rgib_screw.mdl",{BloodDecal="",Pos=self:LocalToWorld(Vector(0,0,20)),CollideSound={"vj_hlr/fx/metal1.wav","vj_hlr/fx/metal2.wav","vj_hlr/fx/metal3.wav","vj_hlr/fx/metal4.wav","vj_hlr/fx/metal5.wav"}})
	end
	return true
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomGibOnDeathSounds(dmginfo,hitgroup)
	VJ_EmitSound(self, "vj_gib/default_gib_splat.wav", 100, math.random(100,100))
	if self.SCI_Type == 2 then
		VJ_EmitSound(self, "vj_hlr/hl1_weapon/explosion/debris3.wav", 150, math.random(100,100))
		VJ_EmitSound(self, "vj_hlr/hl1_npc/rgrunt/rb_gib.wav", 65, math.random(100,100))
	end
	return false
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomDeathAnimationCode(dmginfo,hitgroup)
	if hitgroup == HITGROUP_HEAD then
		self.AnimTbl_Death = {"vjseq_diebackward"}
	elseif hitgroup == HITGROUP_STOMACH && self.SCI_Type != 2 then
		self.AnimTbl_Death = {"vjseq_diesimple"}
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnDeath_AfterCorpseSpawned(dmginfo,hitgroup)
	self.Corpse:RemoveAllDecals()
	self.Corpse:DrawShadow(false)
	self.Corpse:SetMaterial("Invisible")
	self.PropGun = ents.Create("obj_warlord_gun")
	self.PropGun:SetModel("models/drillin/drill_opf.mdl")
	self.PropGun:Spawn()
	self.PropGun:SetParent(self.Corpse)
	self.PropGun:SetSubMaterial(1 ,"spazter/paint_colors/chrome/australium_gold")
	self.PropGun:SetSubMaterial(4 ,"models/chrome/agrunt/chrome2")
	self.PropGun:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
	if self.Sharp == true then
	self.PropGun:SetSkin(0)
	end
	if self.Barnes == true then
	self.PropGun:SetSkin(1)
	end
end
/*-----------------------------------------------
	*** Copyright (c) 2012-2020 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/