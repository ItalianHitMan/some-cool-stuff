AddCSLuaFile("shared.lua")
include('shared.lua')
/*-----------------------------------------------
	*** Copyright (c) 2012-2020 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/
ENT.Model = {"models/vj_hlr/hl1/houndeye.mdl"} -- The game will pick a random model from the table when the SNPC is spawned | Add as many as you want
ENT.StartHealth = 80
ENT.HullType = HULL_WIDE_SHORT
ENT.VJC_Data = {
    FirstP_Bone = "Bip01 Head", -- If left empty, the base will attempt to calculate a position for first person
    FirstP_Offset = Vector(0, 0, 0), -- The offset for the controller when the camera is in first person
}
---------------------------------------------------------------------------------------------------------------------------------------------
ENT.VJ_NPC_Class = {"CLASS_ZOMBIE"} -- NPCs with the same class with be allied to each other
ENT.BloodColor = "Red" -- The blood type, this will determine what it should use (decal, particle, etc.)
ENT.CustomBlood_Particle = {"vj_hl_blood_red"}
ENT.CustomBlood_Decal = {"VJ_HLR_Blood_Red"} -- Decals to spawn when it's damaged
ENT.HasBloodPool = false -- Does it have a blood pool?
ENT.Immune_Sonic = true -- Immune to sonic damage
ENT.HasMeleeAttack = true -- Should the SNPC have a melee attack?
ENT.AnimTbl_MeleeAttack = {"vjseq_madidle2"} -- Melee Attack Animations
ENT.MeleeAttackDistance = 50 -- How close does it have to be until it attacks?
ENT.MeleeAttackDamageDistance = 80 -- How far does the damage go?
ENT.MeleeAttackDamage = 10
ENT.HasExtraMeleeAttackSounds = true -- Set to true to use the extra melee attack sounds
ENT.TimeUntilMeleeAttackDamage = 0.45 -- This counted in seconds | This calculates the time until it hits something
ENT.DisableDefaultMeleeAttackDamageCode = false -- Disables the default melee attack damage code
ENT.HasDeathAnimation = true -- Does it play an animation when it dies?
ENT.AnimTbl_Death = {ACT_DIESIMPLE,ACT_DIEFORWARD,ACT_DIEBACKWARD} -- Death Animations
ENT.DeathAnimationChance = 3 -- Put 1 if you want it to play the animation all the time
ENT.DisableFootStepSoundTimer = true -- If set to true, it will disable the time system for the footstep sound code, allowing you to use other ways like model events
	-- ====== Flinching Code ====== --
ENT.CanFlinch = 1 -- 0 = Don't flinch | 1 = Flinch at any damage | 2 = Flinch only from certain damages
ENT.AnimTbl_Flinch = {"vjseq_flinch_small"} -- If it uses normal based animation, use this
	-- ====== Sound File Paths ====== --
-- Leave blank if you don't want any sounds to play
ENT.SoundTbl_FootStep = {"vj_hlr/th_npc/hunger/hungerhound/he_hunt1.wav","vj_hlr/th_npc/hunger/hungerhound/he_hunt2.wav","vj_hlr/th_npc/hunger/hungerhound/he_hunt3.wav"}
ENT.SoundTbl_Idle = {"vj_hlr/th_npc/hunger/hungerhound/he_idle1.wav","vj_hlr/th_npc/hunger/hungerhound/he_idle2.wav","vj_hlr/th_npc/hunger/hungerhound/he_idle3.wav"}
ENT.SoundTbl_Alert = {"vj_hlr/th_npc/hunger/hungerhound/he_alert1.wav","vj_hlr/th_npc/hunger/hungerhound/he_alert2.wav","vj_hlr/th_npc/hunger/hungerhound/he_alert3.wav"}
ENT.SoundTbl_BeforeMeleeAttack = {"vj_hlr/th_npc/hunger/hungerhound/he_attack1.wav","vj_hlr/th_npc/hunger/hungerhound/he_attack2.wav","vj_hlr/th_npc/hunger/hungerhound/he_attack3.wav"}
ENT.SoundTbl_MeleeAttackExtra = {"vj_hlr/th_npc/hunger/hungerhound/rex_bite1.wav","vj_hlr/th_npc/hunger/hungerhound/rex_bite2.wav","vj_hlr/th_npc/hunger/hungerhound/rex_bite3.wav"}
ENT.SoundTbl_MeleeAttackMiss = {"vj_hlr/hl1_npc/zombie/claw_miss1.wav","vj_hlr/hl1_npc/zombie/claw_miss2.wav"}
ENT.SoundTbl_Pain = {"vj_hlr/th_npc/hunger/hungerhound/he_pain1.wav","vj_hlr/th_npc/hunger/hungerhound/he_pain2.wav","vj_hlr/th_npc/hunger/hungerhound/he_pain3.wav","vj_hlr/th_npc/hunger/hungerhound/he_pain4.wav","vj_hlr/th_npc/hunger/hungerhound/he_pain5.wav"}
ENT.SoundTbl_Death = {"vj_hlr/th_npc/hunger/hungerhound/he_die1.wav","vj_hlr/th_npc/hunger/hungerhound/he_die2.wav","vj_hlr/th_npc/hunger/hungerhound/he_die3.wav"}

ENT.FootStepSoundLevel = 80
ENT.GeneralSoundPitch1 = 100

-- Custom
ENT.Houndeye_BlinkingT = 0
ENT.Houndeye_NextSleepT = 0
ENT.Houndeye_Sleeping = false
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnInitialize()
	self:SetMaterial("Invisible")
	self:DrawShadow(false)
	self.PropGun = ents.Create("obj_warlord_gun")
	self.PropGun:SetModel("models/vj_hlr/theyhunger/houndeye.mdl")
	self.PropGun:SetSubMaterial(5, "models/chrome/baby_headcrab/babychrome")
	self.PropGun:Spawn()
	self.PropGun:SetParent(self)
	self.PropGun:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
	self:SetCollisionBounds(Vector(20, 20 , 40), Vector(-20, -20, 0))
	
	self.Houndeye_NextSleepT = CurTime() + math.Rand(0, 15)
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnAcceptInput(key, activator, caller, data)
	//print(key)
	if key == "he_hunt" then
		self:FootStepSoundCode()
	end
	if key == "placeholder_eye_event_dont_use" then
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnThink()
	if IsValid(self:GetEnemy()) then
		self.AnimTbl_IdleStand = {ACT_IDLE_ANGRY}
	else
		if self.Houndeye_Sleeping == true then
			self.AnimTbl_IdleStand = {ACT_CROUCHIDLE}
		else
			self.AnimTbl_IdleStand = {ACT_IDLE, "leaderlook"}
		end
	end
	
	if (self:GetMaxHealth() * 0.35) > self:Health() then -- Limp walking
		self.AnimTbl_Walk = {ACT_WALK_HURT}
	else
		self.AnimTbl_Walk = {ACT_WALK}
	end
	
	-- Blinking
	if self.Dead == false && CurTime() > self.Houndeye_BlinkingT && self.Houndeye_Sleeping == false then
		self:SetSkin(1)
		timer.Simple(0.1, function() if IsValid(self) then self:SetSkin(2) end end)
		timer.Simple(0.2, function() if IsValid(self) then self:SetSkin(1) end end)
		timer.Simple(0.3, function() if IsValid(self) then self:SetSkin(0) end end)
		self.Houndeye_BlinkingT = CurTime() + math.Rand(2, 3.5)
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnThink_AIEnabled()
	if self.Alerted != true && !IsValid(self:GetEnemy()) && CurTime() > self.Houndeye_NextSleepT && self.Houndeye_Sleeping == false && !self:IsMoving() then
		local sleept = math.Rand(15,30) -- How long it should sleep
		self.Houndeye_Sleeping = true
		self.AnimTbl_IdleStand = {ACT_CROUCHIDLE}
		self:VJ_ACT_PLAYACTIVITY(ACT_CROUCH, true, false, false)
		self:SetState(VJ_STATE_ONLY_ANIMATION, sleept)
		timer.Simple(7, function() if IsValid(self) && self.Houndeye_Sleeping == true then self:SetSkin(2) end end) -- Close eyes
		timer.Simple(sleept, function() -- Reset after sleept seconds
			if IsValid(self) && self.Houndeye_Sleeping == true then 
				self.Houndeye_Sleeping = false
				self:VJ_ACT_PLAYACTIVITY(ACT_STAND, true, false, false)
				self.Houndeye_NextSleepT = CurTime() + math.Rand(15, 45)
			end
		end)
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnAlert(argent)
	if self.Houndeye_Sleeping == true then -- Wake up if sleeping and play a special alert animation
		if self:GetState() == VJ_STATE_ONLY_ANIMATION then self:SetState() end
		self.Houndeye_Sleeping = false
		self:VJ_ACT_PLAYACTIVITY(ACT_HOP, true, false, false)
		self.Houndeye_NextSleepT = CurTime() + 20
	elseif math.random(1,2) == 1 then -- Random alert animation
		self:VJ_ACT_PLAYACTIVITY({"vjseq_madidle1","vjseq_madidle2","vjseq_madidle3"}, true, false, true)
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnResetEnemy()
	self.Houndeye_NextSleepT = CurTime() + math.Rand(15, 45)
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnMeleeAttack_BeforeChecks()
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnFlinch_BeforeFlinch(dmginfo,hitgroup)
	if self.PlayingAttackAnimation == true then
		return false -- Don't flinch if we are playing an attack animation!
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnDeath_AfterCorpseSpawned(dmginfo,hitgroup,GetCorpse)
	self.Corpse:SetMaterial("Invisible")
	self.Corpse:DrawShadow(false)
	self.PropGun = ents.Create("obj_warlord_gun")
	self.PropGun:SetModel("models/vj_hlr/theyhunger/houndeye.mdl")
	self.PropGun:Spawn()
	self.PropGun:SetSubMaterial(5, "models/chrome/baby_headcrab/babychrome")
	self.PropGun:SetParent(self.Corpse)
	self.PropGun:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
	GetCorpse:SetSkin(math.random(1,2))
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:SetUpGibesOnDeath(dmginfo,hitgroup)
	self.HasDeathSounds = false
	if self.HasGibDeathParticles == true then
		local bloodeffect = EffectData()
		bloodeffect:SetOrigin(self:GetPos() +self:OBBCenter())
		bloodeffect:SetColor(VJ_Color2Byte(Color(130,19,10)))
		bloodeffect:SetScale(120)
		util.Effect("VJ_Blood1",bloodeffect)
		
		local bloodspray = EffectData()
		bloodspray:SetOrigin(self:GetPos())
		bloodspray:SetScale(8)
		bloodspray:SetFlags(3)
		bloodspray:SetColor(0)
		util.Effect("bloodspray",bloodspray)
		util.Effect("bloodspray",bloodspray)
	end
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/flesh1.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,40))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/flesh2.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,40))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/flesh3.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,40))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/flesh4.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,40))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/hgib_b_bone.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,50))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/hgib_b_gib.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,40))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/hgib_guts.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,40))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/hgib_hmeat.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,45))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/hgib_lung.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,45))})
	return true -- Return to true if it gibbed!
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomGibOnDeathSounds(dmginfo,hitgroup)
	VJ_EmitSound(self, "vj_gib/default_gib_splat.wav", 90, math.random(100,100))
	return false
end
/*-----------------------------------------------
	*** Copyright (c) 2012-2020 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/