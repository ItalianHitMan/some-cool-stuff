AddCSLuaFile("shared.lua")
include('shared.lua')
/*-----------------------------------------------
	*** Copyright (c) 2012-2020 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/
ENT.Model = {"models/vj_hlr/opfor/massn.mdl"} -- The game will pick a random model from the table when the SNPC is spawned | Add as many as you want
ENT.VJ_NPC_Class = {"CLASS_CRACKHEAD"}
ENT.AnimTbl_MeleeAttack = {ACT_MELEE_ATTACK1,ACT_MELEE_ATTACK2,ACT_MELEE_ATTACK_SWING} -- Melee Attack Animations
ENT.HasPainSounds = false
ENT.HasDeathSounds = false
ENT.SoundTbl_FootStep = {"vj_hlr/crack_fx/npc_step1.wav","vj_hlr/crack_fx/npc_step2.wav","vj_hlr/crack_fx/npc_step3.wav","vj_hlr/crack_fx/npc_step4.wav"}

-- Custom
ENT.BOA_NextStrafeT = 0
ENT.BOA_NextRunT = 0
ENT.Einstein = false
ENT.Slick = false
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:HECU_CustomOnInitialize()
	self:DrawShadow(false)
	self:SetSubMaterial(0, "Invisible")
	self:SetSubMaterial(1, "Invisible")
	self.PropGun = ents.Create("obj_warlord_gun")
	self.PropGun:SetModel("models/uboa/scimassn.mdl")
	self.PropGun:Spawn()
	self.PropGun:SetParent(self)
	self.PropGun:SetBodygroup(2,2)
	self.PropGun:SetSubMaterial(18 ,"spazter/paint_colors/chrome/a_distinctive_lack_of_hue")
	self.PropGun:SetSubMaterial(17 ,"spazter/paint_colors/chrome/a_distinctive_lack_of_hue")
	self.PropGun:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
	self:SetBodygroup(2,0)
	self.BOA_NextStrafeT = CurTime() + 4
	local randmod = math.random(1,2)
	if randmod == 1 then
	self.PropGun:SetBodygroup(1,1)
	self.Einstein = true
	end
	if randmod == 2 then
	self.PropGun:SetBodygroup(1,2)
	self.Slick = true
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:HECU_CustomOnThink()
	if IsValid(self:GetEnemy()) && self.DoingWeaponAttack_Standing == true && self.VJ_IsBeingControlled == false && CurTime() > self.BOA_NextStrafeT && !self:IsMoving() && self:GetPos():Distance(self:GetEnemy():GetPos()) < 1400 then
		self:StopMoving()
		self:VJ_ACT_PLAYACTIVITY({ACT_STRAFE_RIGHT,ACT_STRAFE_LEFT},true,false,false)
		self.BOA_NextRunT = CurTime() + 2
		//if self:GetBodygroup(2) == 1 then
			//self.BOA_NextStrafeT = CurTime() + 2
		//else
			self.BOA_NextStrafeT = CurTime() + 8
		//end
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnWeaponAttack()
	if CurTime() > self.BOA_NextRunT then
		timer.Simple(0.8,function() 
			if IsValid(self) && !self:IsMoving() && self.Dead == false then
				self:VJ_TASK_COVER_FROM_ENEMY("TASK_RUN_PATH")
			end
		end)
		//if self:GetBodygroup(2) == 1 then
			///self.BOA_NextStrafeT = CurTime() + 5
			//self.BOA_NextRunT = CurTime() + 8
		//else
			self.BOA_NextStrafeT = CurTime() + 8
			self.BOA_NextRunT = CurTime() + 12
		//end
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnDeath_AfterCorpseSpawned(dmginfo,hitgroup)
	self.Corpse:DrawShadow(false)
	self.Corpse:SetSubMaterial(0, "Invisible")
	self.Corpse:SetSubMaterial(1, "Invisible")
	self.PropGun = ents.Create("obj_warlord_gun")
	self.PropGun:SetModel("models/uboa/scimassn.mdl")
	self.PropGun:Spawn()
	self.PropGun:SetParent(self.Corpse)
	self.PropGun:SetBodygroup(2,2)
	self.PropGun:SetSubMaterial(18 ,"spazter/paint_colors/chrome/a_distinctive_lack_of_hue")
	self.PropGun:SetSubMaterial(17 ,"spazter/paint_colors/chrome/a_distinctive_lack_of_hue")
	self.PropGun:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
	if self.Slick == true then
	self.PropGun:SetBodygroup(1,2)
	end
	if self.Einstein == true then
	self.PropGun:SetBodygroup(1,1)
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomGibOnDeathSounds(dmginfo,hitgroup)
	VJ_EmitSound(self,"vj_hlr/crack_fx/bodysplat.wav", 90, math.random(100,100))
	VJ_EmitSound(self, "vj_gib/default_gib_splat.wav", 90, math.random(100,100))
	return false
end
/*-----------------------------------------------
	*** Copyright (c) 2012-2020 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/