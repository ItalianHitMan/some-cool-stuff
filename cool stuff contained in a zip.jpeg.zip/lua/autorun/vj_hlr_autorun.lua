/*--------------------------------------------------
	=============== Autorun File ===============
	*** Copyright (c) 2012-2020 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
--------------------------------------------------*/
------------------ Addon Information ------------------
local PublicAddonName = "Half-Life Resurgence"
local AddonName = "Half-Life Resurgence"
local AddonType = "SNPC"
local AutorunFile = "autorun/vj_hlr_autorun.lua"
-------------------------------------------------------

local VJExists = file.Exists("lua/autorun/vj_base_autorun.lua","GAME")
if VJExists == true then
	include('autorun/vj_controls.lua')
	
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------ Gold Source Engine ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	local vCat = "HL Resurgence: GoldSrc"
	local cCat = "Half-Life Resurgence: Crack-Life"
	local fCat = "HL Resurgence: Friendly"
	local tCat = "HL Resurgence: They Hunger"
	VJ.AddCategoryInfo(vCat, {Icon = "vj_hl/icons/hl1.png"})
	VJ.AddCategoryInfo(fCat, {Icon = "vj_hl/icons/hl1.png"})
	VJ.AddCategoryInfo(tCat, {Icon = "vj_hl/icons/th.png"})
	
	-- Earth
	VJ.AddNPC("Cockroach","npc_vj_hlr1_cockroach",vCat)
		
		-- Black Mesa Personnel
		VJ.AddNPC("Father Grigori","npc_vj_hlr1_monk",vCat)
		VJ.AddNPC("Security Guard","npc_vj_hlr1_securityguard",vCat)
		VJ.AddNPC("Security Guard (Female)","npc_vj_hlr1_fem_securityguard",vCat)
		VJ.AddNPC("HEV Scientist","npc_vj_hlr1_hev_scientist",vCat)
		VJ.AddNPC("Scientist","npc_vj_hlr1_scientist",vCat)
		VJ.AddNPC("Scientist (Female)","npc_vj_hlr1_fem_scientist",vCat)
		VJ.AddNPC("Administrator","npc_vj_hlr1_admin",vCat)
		VJ.AddNPC("Chef","npc_vj_hlr1_chef",vCat)
		VJ.AddNPC("Construction Worker","npc_vj_hlr1_construction_worker",vCat)
			-- Blue Shift
			VJ.AddNPC("Scientist (Civilian)","npc_vj_hlrbs_civ_scientist",vCat)
			VJ.AddNPC("Security Guard (Civilian)","npc_vj_hlrbs_civ_barney",vCat)
			VJ.AddNPC("Dr. Rosenberg","npc_vj_hlrbs_rosenberg",vCat)
			-- Opposing Force
			VJ.AddNPC("Cleansuit Scientist","npc_vj_hlrof_cleansuitsci",vCat)
			VJ.AddNPC("Otis Laurey","npc_vj_hlrof_otis",vCat)
			VJ.AddNPC("Otis Laurey (Civilian)","npc_vj_hlrof_civ_otis",vCat)
			-- Decay
			VJ.AddNPC("Dr. Richard Keller","npc_vj_hlrdc_keller",vCat)
			-- Alpha
			VJ.AddNPC("Alpha Security Guard","npc_vj_hlr1a_securityguard",vCat)
			VJ.AddNPC("Alpha Scientist","npc_vj_hlr1a_scientist",vCat)
			VJ.AddNPC("Ivan the Space Biker","npc_vj_hlr1a_ivan",vCat)
			-- Azure Sheep
			VJ.AddNPC("Security Commander (Female)","npc_vj_hlr1_fem_securitycommander",vCat)
			VJ.AddNPC("Security Commander","npc_vj_hlr1_securitycommander",vCat)
			-- Brutal Half-life
			VJ.AddNPC("Security Guard (Extras)","npc_vj_hlr1_securityguard_weapons",vCat)
			VJ.AddNPC("Security Guard (RPG)","npc_vj_hlr1_securityguard_rpg",vCat)
			
		-- Black Mesa Security Weaponry
		VJ.AddNPC("Ceiling Turret (Large)","npc_vj_hlr1_turret",vCat,false,function(x) x.OnCeiling = true x.Offset = 0 end)
		VJ.AddNPC("Ceiling Turret (Small)","npc_vj_hlr1_turret_small",vCat,false,function(x) x.OnCeiling = true x.Offset = 0 end)

		-- HECU
		VJ.AddNPC("Mounted Gun","sent_vj_hlr1_mountedturret",vCat)
		VJ.AddNPC("HECU Radio","npc_vj_hlr1_radio",vCat)
		VJ.AddNPC("Human Grunt","npc_vj_hlr1_hgrunt",vCat)
		VJ.AddNPC("Human Officer","npc_vj_hlr1_hofficer",vCat)
		VJ.AddNPC("Human Sergeant","npc_vj_hlr1_hgrunt_serg",vCat)
		VJ.AddNPC("Robot Grunt","npc_vj_hlr1_rgrunt",vCat)
		VJ.AddNPC("HECU Sentry Gun","npc_vj_hlr1_sentry",vCat)
		VJ.AddNPC("M2A3 Bradley","npc_vj_hlr1_m2a3bradley",vCat)
		VJ.AddNPC("M1A1 Abrams","npc_vj_hlr1_m1a1abrams",vCat)
			-- Opposing Force
			VJ.AddNPC("Drill Instructor","npc_vj_hlrof_drill_sergeant",vCat)
			VJ.AddNPC("Human Grunt (OppF)","npc_vj_hlrof_hgrunt",vCat)
			VJ.AddNPC("Human Grunt Medic (OppF)","npc_vj_hlrof_hgrunt_med",vCat)
			VJ.AddNPC("Human Grunt Engineer (OppF)","npc_vj_hlrof_hgrunt_eng",vCat)
			-- Decay
			VJ.AddNPC("Decay HECU Sentry Gun","npc_vj_hlrdc_sentry",vCat)
			-- Alpha
			VJ.AddNPC("Alpha Human Grunt","npc_vj_hlr1a_hgrunt",vCat)
			-- Sven Co-Op
			VJ.AddNPC("HECU Scientist","npc_vj_hlrsv_hecu_scientist",vCat)
			VJ.AddNPC("Otto","npc_vj_hlrsv_otto",vCat)
			VJ.AddNPC("Barnabus","npc_vj_hlrsv_barnabus",vCat)
			VJ.AddNPC("Human Rocketeer","npc_vj_hlrsv_hgrunt_rpg",vCat)
			-- Friendly
			VJ.AddNPC("Recruit","npc_vj_hlrf_recon",fCat)
			VJ.AddNPC("HECU Scientist","npc_vj_hlrf_hecu_scientist",fCat)
			VJ.AddNPC("Otto","npc_vj_hlrf_otto",fCat)
			VJ.AddNPC("Barnabus","npc_vj_hlrf_barnabus",fCat)
			VJ.AddNPC("Drill Instructor","npc_vj_hlrf_drill_sergeant",fCat)
			VJ.AddNPC("Human Grunt (OppF)","npc_vj_hlrf_hgrunt_of",fCat)
			VJ.AddNPC("Human Grunt Medic (OppF)","npc_vj_hlrf_hgrunt_med",fCat)
			VJ.AddNPC("Human Grunt Engineer (OppF)","npc_vj_hlrf_hgrunt_eng",fCat)
			VJ.AddNPC("Decay HECU Sentry Gun","npc_vj_hlrfdc_sentry",fCat)
			VJ.AddNPC("Human Grunt","npc_vj_hlrf_hgrunt",fCat)
			VJ.AddNPC("Human Officer","npc_vj_hlrf_hofficer",fCat)
			VJ.AddNPC("Human Sergeant","npc_vj_hlrf_hgrunt_serg",fCat)
			VJ.AddNPC("Human Rocketeer","npc_vj_hlrf_hgrunt_rpg",fCat)
			VJ.AddNPC("Robot Grunt","npc_vj_hlrf_rgrunt",fCat)
			VJ.AddNPC("HECU Sentry Gun","npc_vj_hlrf_sentry",fCat)
			VJ.AddNPC("M2A3 Bradley","npc_vj_hlrf_m2a3bradley",fCat)
			VJ.AddNPC("M1A1 Abrams","npc_vj_hlrf_m1a1abrams",fCat)

		-- Black Ops
		VJ.AddNPC("Black Ops Female Assassin","npc_vj_hlr1_assassin_female",vCat)
		VJ.AddNPC("Black Ops Male Assassin","npc_vj_hlrof_assassin_male",vCat)
		VJ.AddNPC("Black Ops Robot Assassin","npc_vj_hlrof_assassin_rgrunt",vCat)
	
	-- Xen
	VJ.AddNPC("Gonarch","npc_vj_hlr1_gonarch",vCat)
	VJ.AddNPC("Headcrab","npc_vj_hlr1_headcrab",vCat)
	VJ.AddNPC("Fast Headcrab","npc_vj_hlr1_headcrab_fast",vCat)
	VJ.AddNPC("Poison Headcrab","npc_vj_hlr1_headcrab_poison",vCat)
	VJ.AddNPC("Headcrab (Baby)","npc_vj_hlr1_headcrab_baby",vCat)
	VJ.AddNPC("Zombie","npc_vj_hlr1_zombie",vCat)
	VJ.AddNPC("Zombie Brute","npc_vj_hlr1_zombie_brute",vCat)
	VJ.AddNPC("Fast Zombie","npc_vj_hlr1_zombie_fast",vCat)
	VJ.AddNPC("Poison Zombie","npc_vj_hlr1_zombie_poison",vCat)
	VJ.AddNPC("Poison Zombie Scientist","npc_vj_hlr1_zombie_scientist_poison",vCat)
	VJ.AddNPC("HEV Zombie","npc_vj_hlr1_hev_zombie",vCat)
	VJ.AddNPC("Flocking Floater","npc_vj_hlr1_floater",vCat)
	VJ.AddNPC("Alien Controller","npc_vj_hlr1_aliencontroller",vCat)
	VJ.AddNPC("Alien Grunt","npc_vj_hlr1_aliengrunt",vCat)
	VJ.AddNPC("Alien Grunt (Melee)","npc_vj_hlr1_aliengrunt_melee",vCat)
	VJ.AddNPC("Alien Slave","npc_vj_hlr1_alienslave",vCat)
	VJ.AddNPC("Alien Medic","npc_vj_hlr1_alienmedic",vCat)
	VJ.AddNPC("Bullsquid","npc_vj_hlr1_bullsquid",vCat)
	VJ.AddNPC("AirHead","npc_vj_hlrcl_bullsquid",cCat)
	VJ.AddNPC("WTF Hopper","npc_vj_hlrcl_skull",cCat)
	VJ.AddNPC("Sihts","npc_vj_hlrcl_sihts",cCat)
	VJ.AddNPC("Super Bozo","npc_vj_hlrcl_superbozo",cCat)
	VJ.AddNPC("Electric Guard Gopnik","npc_vj_hlrcl_electric_guard_gopnik",cCat)
	VJ.AddNPC("Poly Man","npc_vj_hlrcl_poly",cCat)
	VJ.AddNPC("Whacking great Ottiz","npc_vj_hlrcl_zombie_otis",cCat)
	VJ.AddNPC("B-A-R-N","npc_vj_hlrcl_barn",cCat)
	VJ.AddNPC("Mr.X","npc_vj_hlrcl_mrx",cCat)
	VJ.AddNPC("Navy Seal Trooper","npc_vj_hlrcl_navy_seal",cCat)
	VJ.AddNPC("The Authorites","npc_vj_hlrcl_authorities",cCat)
	VJ.AddNPC("Zombozo Bozz","npc_vj_hlrcl_zombozo_bozz",cCat)
	VJ.AddNPC("Gargantua","npc_vj_hlr1_garg",vCat)
	VJ.AddNPC("Houndeye","npc_vj_hlr1_houndeye",vCat)
	VJ.AddNPC("Kingpin","npc_vj_hlr1_kingpin",vCat)
	VJ.AddNPC("Snark","npc_vj_hlr1_snark",vCat)
	VJ.AddNPC("Snark Nest","npc_vj_hlr1_snarknest",vCat)
	VJ.AddNPC("Ichthyosaur","npc_vj_hlr1_ichthyosaur",vCat)
	VJ.AddNPC("Archer","npc_vj_hlr1_archer",vCat)
	VJ.AddNPC("Leech","npc_vj_hlr1_leech",vCat)
	VJ.AddNPC("Chumtoad","npc_vj_hlr1_chumtoad",vCat)
	VJ.AddNPC("Boid","npc_vj_hlr1_boid",vCat)
	VJ.AddNPC("AFlock","npc_vj_hlr1_aflock",vCat)
	VJ.AddNPC("Protozoan","npc_vj_hlr1_protozoan",vCat)
	VJ.AddNPC("Tentacle","npc_vj_hlr1_tentacle",vCat)
	VJ.AddNPC("Panther Eye","npc_vj_hlr1_panthereye",vCat)
	VJ.AddNPC("Control Sphere","npc_vj_hlr1_controlsphere",vCat)
	VJ.AddNPC("Mr. Friendly","npc_vj_hlr1_mrfriendly",vCat)
	VJ.AddNPC("Nihilanth","npc_vj_hlr1_nihilanth",vCat)
	VJ.AddNPC("Barnacle","npc_vj_hlr1_barnacle",vCat,false,function(x) x.OnCeiling = true x.Offset = 0 end)
	VJ.AddNPC("Xen Tree","npc_vj_hlr1_xentree",vCat)
	VJ.AddNPC("Xen Hair","sent_vj_xen_hair",vCat)
	VJ.AddNPC("Xen Spore (Large)","sent_vj_xen_spore_large",vCat)
	VJ.AddNPC("Xen Spore (Medium)","sent_vj_xen_spore_medium",vCat)
	VJ.AddNPC("Xen Spore (Small)","sent_vj_xen_spore_small",vCat)
	VJ.AddNPC("Xen Plant Light","sent_vj_xen_plant_light",vCat)
	VJ.AddNPC("Xen Crystal","sent_vj_xen_crystal",vCat)
	VJ.AddNPC("Xen Sentry Cannon","npc_vj_hlr1_xen_cannon",vCat)
	VJ.AddNPC("Xen Ceiling Turret","npc_vj_hlr1_xen_turretc",vCat,false,function(x) x.OnCeiling = true x.Offset = 0 end)
		-- Spawners
		VJ.AddNPC("Portal (Xen)","sent_vj_hlr_alientp",vCat)
		VJ.AddNPC("Portal (Race X)","sent_vj_hlr_alientp_x",vCat)
		-- Alpha
		VJ.AddNPC("Alpha Zombie","npc_vj_hlr1a_zombie",vCat)
		VJ.AddNPC("Alpha Headcrab","npc_vj_hlr1a_headcrab",vCat)
		VJ.AddNPC("Alpha Bullsquid","npc_vj_hlr1a_bullsquid",vCat)
		-- Opposing Force
		VJ.AddNPC("Zombie Security Guard","npc_vj_hlrof_zombie_sec",vCat)
		VJ.AddNPC("Zombie Soldier","npc_vj_hlrof_zombie_soldier",vCat)
		VJ.AddNPC("Zombie Cleansuit","npc_vj_hlrof_zombie_cleansuit",vCat)
		VJ.AddNPC("Zombie Male Assassin","npc_vj_hlrof_zombie_male_assassin",vCat)
		VJ.AddNPC("Zombie Female Assassin","npc_vj_hlrof_zombie_female_assassin",vCat)
		VJ.AddNPC("Gonome","npc_vj_hlrof_gonome",vCat)
		VJ.AddNPC("Gonome Security Guard","npc_vj_hlrof_gonome_sec",vCat)
		VJ.AddNPC("Gonome Soldier","npc_vj_hlrof_gonome_soldier",vCat)
		VJ.AddNPC("Poison Zombie Security","npc_vj_hlrof_zombie_sec_poison",vCat)
		VJ.AddNPC("Poison Zombie Soldier","npc_vj_hlrof_zombie_soldier_poison",vCat)
		VJ.AddNPC("Penguin","npc_vj_hlrof_penguin",vCat)
		VJ.AddNPC("Penguin Nest","npc_vj_hlrof_penguinnest",vCat)
		-- Sven Co-Op
		VJ.AddNPC("Gargantua (Baby)","npc_vj_hlrsv_garg_baby",vCat)
		VJ.AddNPC("Tor","npc_vj_hlrsv_tor",vCat)
		VJ.AddNPC("Zombie Barnabus","npc_vj_hlrsv_zombie_barnabus",vCat)
	
	-- Race X (Opposing Force)
	VJ.AddNPC("Shock Trooper","npc_vj_hlrof_shocktrooper",vCat)
	VJ.AddNPC("Shock Roach","npc_vj_hlrof_shockroach",vCat)
	VJ.AddNPC("Pit Drone","npc_vj_hlrof_pitdrone",vCat)
	VJ.AddNPC("Pit Worm","npc_vj_hlrof_pitworm",vCat)
	VJ.AddNPC("Voltigore","npc_vj_hlrof_voltigore",vCat)
	VJ.AddNPC("Voltigore (Baby)","npc_vj_hlrof_voltigore_baby",vCat)
	VJ.AddNPC("Gene Worm","npc_vj_hlrof_geneworm",vCat)
	
	-- Unknown
	VJ.AddNPC("G-Man","npc_vj_hlr1_gman",vCat)

	-- They Hunger
	VJ.AddNPC("Zombie Cop Gunner","npc_vj_hlrth_zombie_cop_gun",tCat)
	VJ.AddNPC("Zombie Fat Cop Gunner","npc_vj_hlrth_zombie_fat_cop_gun",tCat)
	VJ.AddNPC("Sheriff","npc_vj_hlrth_sheriff",tCat)
	VJ.AddNPC("Sheriff (Cutscene)","npc_vj_hlrth_sheriff_cutscene",tCat)
	VJ.AddNPC("Zombie Asylum Security Gunner","npc_vj_hlrth_zombie_asylum_gun",tCat)
	VJ.AddNPC("Human Soldier","npc_vj_hlrth_hgrunt",tCat)
	VJ.AddNPC("Human Soldier (Parachute)","npc_vj_hlrth_hgrunt_parachute",tCat)
	VJ.AddNPC("Human Sniper","npc_vj_hlrth_hsniper",tCat)
	VJ.AddNPC("Human Sniper (Parachute)","npc_vj_hlrth_hsniper_parachute",tCat)
	VJ.AddNPC("Human Officer","npc_vj_hlrth_hofficer",tCat)
	VJ.AddNPC("Human Officer (Parachute)","npc_vj_hlrth_hofficer_parachute",tCat)
	VJ.AddNPC("Human Cop","npc_vj_hlrth_cop",tCat)
	VJ.AddNPC("Human Asylum Security","npc_vj_hlrth_asylum",tCat)
	VJ.AddNPC("Headcrab","npc_vj_hlrth_headcrab",tCat)
	VJ.AddNPC("Hand","npc_vj_hlrth_hand",tCat)
	VJ.AddNPC("Zombie","npc_vj_hlrth_zombie",tCat)
	VJ.AddNPC("Zombie Nurse","npc_vj_hlrth_zombie_nurse",tCat)
	VJ.AddNPC("Zombie Chef","npc_vj_hlrth_zombie_chef",tCat)
	VJ.AddNPC("Zombie Priest","npc_vj_hlrth_zombie_priest",tCat)
	VJ.AddNPC("Zombie Cop","npc_vj_hlrth_zombie_cop",tCat)
	VJ.AddNPC("Zombie Commander","npc_vj_hlrth_zombie_commander",tCat)
	VJ.AddNPC("Zombie Doctor","npc_vj_hlrth_zombie_doctor",tCat)
	VJ.AddNPC("Zombie Dog","npc_vj_hlrth_hound",tCat)
	VJ.AddNPC("Cyborg Franklin","npc_vj_hlrth_franklin2",tCat)
	VJ.AddNPC("Zombie Patient","npc_vj_hlrth_zombie_patient",tCat)
	VJ.AddNPC("Zombie Biohazard","npc_vj_hlrth_zombie_biohazard",tCat)
	VJ.AddNPC("Burnt Zombie","npc_vj_hlrth_zombie_burnt",tCat)
	VJ.AddNPC("Suicider Zombie","npc_vj_hlrth_zombie_suicider",tCat)
	VJ.AddNPC("Zombie Mechanic","npc_vj_hlrth_zombie_mechanic",tCat)
	VJ.AddNPC("Zombie Grandad","npc_vj_hlrth_zombie_gramps",tCat)
	VJ.AddNPC("Zombie Granny","npc_vj_hlrth_zombie_granny",tCat)
	VJ.AddNPC("Zombie Bubba","npc_vj_hlrth_zombie_bubba",tCat)
	VJ.AddNPC("Zombie Lumberjack","npc_vj_hlrth_zombie_shovel",tCat)
	VJ.AddNPC("Zombie Soldier","npc_vj_hlrth_zgrunt",tCat)
	VJ.AddNPC("Zombie Sniper","npc_vj_hlrth_zsniper",tCat)
	VJ.AddNPC("Zombie Officer","npc_vj_hlrth_zofficer",tCat)
	VJ.AddNPC("Zombie Chicken","npc_vj_hlrth_zombie_chicken",tCat)
	VJ.AddNPC("Zork","npc_vj_hlrth_zork",tCat)
	VJ.AddNPC("Skeleton","npc_vj_hlrth_skelly",tCat)
	VJ.AddNPC("Baby Skeleton","npc_vj_hlrth_babyskelly",tCat)
	VJ.AddNPC("Human Pilot","npc_vj_hlrth_pilot",tCat)
	VJ.AddNPC("Human Civilian","npc_vj_hlrth_civ",tCat)
	VJ.AddNPC("Human Civilian (Clipboard)","npc_vj_hlrth_civ_book",tCat)
	VJ.AddNPC("Human Chef","npc_vj_hlrth_chef",tCat)
	VJ.AddNPC("Human Patient","npc_vj_hlrth_patient",tCat)
	VJ.AddNPC("Human Patient (Clipboard)","npc_vj_hlrth_patient_book",tCat)
	VJ.AddNPC("Human Scientist","npc_vj_hlrth_scientist",tCat)
	VJ.AddNPC("Human Scientist (Clipboard)","npc_vj_hlrth_scientist_book",tCat)
	VJ.AddNPC("Human Priest","npc_vj_hlrth_priest",tCat)
	VJ.AddNPC("Human Priest (Bibble)","npc_vj_hlrth_priest_book",tCat)
	VJ.AddNPC("Human Biohazard","npc_vj_hlrth_biohazard",tCat)
	VJ.AddNPC("Franklin","npc_vj_hlrth_franklin",tCat)
	VJ.AddNPC("Alfred","npc_vj_hlrth_alfred",tCat)
	VJ.AddNPC("Phill","npc_vj_hlrth_phill",tCat)
	VJ.AddNPC("Ludwig","npc_vj_hlrth_ludwig",tCat)
	VJ.AddNPC("Bullsquid","npc_vj_hlrth_bullsquid",tCat)
	VJ.AddNPC("Megasquid","npc_vj_hlrth_megasquid",tCat)
	VJ.AddNPC("Zombie Bull","npc_vj_hlrth_zombie_bull",tCat)
	VJ.AddNPC("Zombie Rat","npc_vj_hlrth_rat",tCat)
	VJ.AddNPC("Human Nurse","npc_vj_hlrth_nurse",tCat)

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------ Source Engine ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	vCat = "HL Resurgence: Source"
	VJ.AddCategoryInfo(vCat, {Icon = "vj_hl/icons/hl2.png"})
	
	-- Earth + Resistance
	VJ.AddNPC("Citizen","npc_vj_hlr2_citizen",vCat)
	VJ.AddNPC_HUMAN("Refugee","npc_vj_hlr2_refugee",{"weapon_vj_crowbar","weapon_vj_357","weapon_vj_9mmpistol","weapon_vj_smg1"},vCat)
	VJ.AddNPC_HUMAN("Rebel Engineer","npc_vj_hlr2_rebel_engineer",{"weapon_vj_spas12"/*,"weapon_vj_hlr2_chargebow"*/},vCat)
	VJ.AddNPC_HUMAN("Rebel","npc_vj_hlr2_rebel",{
		-- 5 = Very common, 4 = Common, 3 = Uncommon, 2 = Rare, 1 = Very rare
		"weapon_vj_smg1",
		"weapon_vj_smg1",
		"weapon_vj_smg1",
		"weapon_vj_smg1",
		"weapon_vj_smg1",
		"weapon_vj_ar2",
		"weapon_vj_ar2",
		"weapon_vj_ar2",
		"weapon_vj_ar2",
		"weapon_vj_spas12",
		"weapon_vj_spas12",
		"weapon_vj_spas12",
		"weapon_vj_crossbow",
		"weapon_vj_crossbow",
		"weapon_vj_9mmpistol",
		"weapon_vj_9mmpistol",
		"weapon_vj_357",
		"weapon_vj_357",
		"weapon_vj_hlr2_rpg"},vCat)
	VJ.AddNPC_HUMAN("Alyx Vance","npc_vj_hlr2_alyx",{"weapon_vj_hlr2_alyxgun"},vCat)
	VJ.AddNPC_HUMAN("Barney Calhoun","npc_vj_hlr2_barney",{"weapon_vj_smg1","weapon_vj_smg1","weapon_vj_smg1","weapon_vj_ar2","weapon_vj_ar2","weapon_vj_spas12"},vCat)
	VJ.AddNPC_HUMAN("Father Grigori","npc_vj_hlr2_father_grigori",{"weapon_vj_hlr2_annabelle"},vCat)
	VJ.AddNPC("Resistance Ground Turret","npc_vj_hlr2_turret",vCat)
	
	-- Combine
	VJ.AddNPC_HUMAN("Overwatch Soldier","npc_vj_hlr2_com_soldier",{"weapon_vj_smg1","weapon_vj_smg1","weapon_vj_smg1","weapon_vj_smg1","weapon_vj_ar2","weapon_vj_ar2"},vCat)
	VJ.AddNPC_HUMAN("Overwatch Shotgun Soldier","npc_vj_hlr2_com_shotgunner",{"weapon_vj_spas12"},vCat)
	VJ.AddNPC_HUMAN("Overwatch Elite","npc_vj_hlr2_com_elite",{"weapon_vj_ar2"},vCat)
	VJ.AddNPC_HUMAN("Overwatch Prison Guard","npc_vj_hlr2_com_prospekt",{"weapon_vj_smg1","weapon_vj_smg1","weapon_vj_ar2","weapon_vj_ar2"},vCat)
	VJ.AddNPC_HUMAN("Overwatch Prison Shotgun Guard","npc_vj_hlr2_com_prospekt_sg",{"weapon_vj_spas12"},vCat)
	VJ.AddNPC_HUMAN("Overwatch Sniper","npc_vj_hlr2_com_sniper",{"weapon_vj_hlr2_csniper"},vCat)
	VJ.AddNPC_HUMAN("Overwatch Engineer","npc_vj_hlr2_com_engineer",{"weapon_vj_hlr2_reager"},vCat)
	VJ.AddNPC_HUMAN("Civil Protection","npc_vj_hlr2_com_civilp",{"weapon_vj_9mmpistol","weapon_vj_9mmpistol","weapon_vj_smg1"},vCat)
	VJ.AddNPC_HUMAN("Civil Protection Elite","npc_vj_hlr2_com_civilp_elite",{"weapon_vj_smg1"},vCat)
	VJ.AddNPC("Overwatch Ground Turret","npc_vj_hlr2_com_turret",vCat)
	
	-- NPC Weapons
	VJ.AddNPCWeapon("VJ_Combine_Sniper","weapon_vj_hlr2_csniper")
	VJ.AddNPCWeapon("VJ_Annabelle","weapon_vj_hlr2_annabelle")
	VJ.AddNPCWeapon("VJ_Alyx_Gun","weapon_vj_hlr2_alyxgun")
	VJ.AddNPCWeapon("VJ_Charge_Bow","weapon_vj_hlr2_chargebow")
	VJ.AddNPCWeapon("VJ_Combine_Reager","weapon_vj_hlr2_reager")
	VJ.AddNPCWeapon("VJ_StunStick","weapon_vj_hlr2_stunstick")
	VJ.AddNPCWeapon("VJ_RPG_Resistance","weapon_vj_hlr2_rpg")
		-- Beta
		VJ.AddNPCWeapon("VJ_OICW","weapon_vj_hlr2b_oicw")
	
	-- Player Weapons
	vCat = "Half-Life Resurgence"
	VJ.AddCategoryInfo(vCat, {Icon = "vj_hl/icons/hl2.png"})
	VJ.AddWeapon("Combine Sniper","weapon_vj_hlr2_csniper",false,vCat)
	VJ.AddWeapon("Alyx Gun","weapon_vj_hlr2_alyxgun",false,vCat)
	VJ.AddWeapon("Charge Bow","weapon_vj_hlr2_chargebow",false,vCat)
	VJ.AddWeapon("Resistance RPG","weapon_vj_hlr2_rpg",false,vCat)
	
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------ Decals ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		-- Blood
		game.AddDecal("VJ_HLR_Blood_Red",{"vj_hl/decals/hl_blood01","vj_hl/decals/hl_blood02","vj_hl/decals/hl_blood03","vj_hl/decals/hl_blood04","vj_hl/decals/hl_blood05","vj_hl/decals/hl_blood06","vj_hl/decals/hl_blood07","vj_hl/decals/hl_blood08"})
		game.AddDecal("VJ_HLR_Blood_Red_Large",{"vj_hl/decals/hl_bigblood01","vj_hl/decals/hl_bigblood02"})
		game.AddDecal("VJ_HLR_Blood_Yellow",{"vj_hl/decals/hl_yblood01","vj_hl/decals/hl_yblood02","vj_hl/decals/hl_yblood03","vj_hl/decals/hl_yblood04","vj_hl/decals/hl_yblood05","vj_hl/decals/hl_yblood06"})
		-- Spits
		game.AddDecal("VJ_HLR_Spit_Acid",{"vj_hl/decals/spit1","vj_hl/decals/spit2"})
		//game.AddDecal("VJ_HLR_Spit_Gonarch",{"vj_hl/decals/gonarch"})
		game.AddDecal("VJ_HLR_Gonarch_Blob",{"vj_hl/decals/mommablob"})
		-- Scorchs
		game.AddDecal("VJ_HLR_Scorch",{"vj_hl/decals/scorch1","vj_hl/decals/scorch2","vj_hl/decals/scorch3"})
		game.AddDecal("VJ_HLR_Scorch_Small",{"vj_hl/decals/smscorch1","vj_hl/decals/smscorch2","vj_hl/decals/smscorch3"})
		game.AddDecal("VJ_HLR_Gargantua_Stomp",{"vj_hl/decals/gargstomp"})
		-- Bullet Holes
		game.AddDecal("VJ_HLR_BULLET_HOLE",{"vj_hl/decals/shot1","vj_hl/decals/shot2","vj_hl/decals/shot3","vj_hl/decals/shot4","vj_hl/decals/shot5"})
		/*
		function SWEP:CustomOnPrimaryAttack_BulletCallback(attacker,tr,dmginfo)
			util.Decal("VJ_HLR_BULLET_HOLE", tr.HitPos + tr.HitNormal, tr.HitPos - tr.HitNormal)
		end
		*/
		
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------ Particles ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	VJ.AddParticle("particles/vj_hl_blood.pcf",{
		"vj_hl_blood_red",
		"vj_hl_blood_red_large",
		"vj_hl_blood_yellow",
		"vj_hl_blood_yellow_large",
		"vj_hl_blood_boob_red",
		"vj_hl_blood_boob_yellow",
	})
	VJ.AddParticle("particles/vj_hlr_garg_flame.pcf",{
		"vj_hlr_garg_flame",
		"vj_hlr_garg_flame_small",
	})
	VJ.AddParticle("particles/vj_hl_shocktrooper.pcf",{
		"vj_hl_shockroach",
		"vj_hl_shockroach_aura",
		"vj_hl_shockroach_bright",
		"vj_hl_shockroach_trail",
	})
	VJ.AddParticle("particles/vj_hl_sporegrenade.pcf",{
		"vj_hl_spore",
		"vj_hl_spore_idle",
		"vj_hl_spore_splash1",
		"vj_hl_spore_splash2",
	})
	VJ.AddParticle("particles/vj_hl_gonome.pcf",{
		"vj_hl_gonome",
		"vj_hl_gonome_idle",
	})
	VJ.AddParticle("particles/vj_hl_spit.pcf",{
		"vj_hl_spit_bullsquid",
		"vj_hl_spit_bullsquid_impact",
		"vj_hl_spit_drone",
		"vj_hl_spit_drone_impact",
		"vj_hl_spit_drone_spawn",
		"vj_hl_spit_gonarch",
		"vj_hl_spit_gonarch_impact",
		"vj_hl_spit_spore_spawn",
		"vj_hlr_spit_friendly",
		"vj_hlr_spit_friendly_b",
		"vj_hlr_spit_friendly_impact",
	})
	VJ.AddParticle("particles/vj_hl_torch.pcf",{
		"vj_hl_torch",
	})
	VJ.AddParticle("particles/vj_hl_muzzle.pcf",{
        "vj_hl_muz1", -- Tau
        "vj_hl_muz2", -- HD pistol
        "vj_hl_muz3", -- HD MP5
        "vj_hl_muz4", -- HD Hornet
        "vj_hl_muz5", -- LD Hornet 1
        "vj_hl_muz6", -- LD Hornet 2
        "vj_hl_muz7", -- HD Hornet 2?
        "vj_hl_muz8", -- HD Brush turret
        "vj_hl_muzzle1", -- LD Pistol (Also used by LD brush turret, I'll make another one that's bigger)
        "vj_hl_muzzle2", -- LD MP5
        "vj_hl_muzzle3", -- LD Shotgun
        "vj_hl_muzzle4", -- HD Pistol 2?
		"vj_hl_muzzlebigturret",
	})
	VJ.AddParticle("particles/vj_hlr_garg_stomp.pcf",{
		"vj_hlr_garg_stomp",
	})
	VJ.AddParticle("particles/vj_hlr_nihilanth.pcf",{
		"vj_hlr_nihilanth_chargeorb",
		"vj_hlr_nihilanth_deathorbs",
		"vj_hlr_nihilanth_deathorbs_white",
	})
	VJ.AddParticle("particles/vj_hlr_geneworm.pcf",{
		"vj_hlr_geneworm_spit",
		"vj_hlr_geneworm_spit_b",
	})
	
	VJ.AddParticle("particles/electrical_fx.pcf",{
		"electrical_arc_01", -- Used for the Combine Reager
	})
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------ Precaches ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	util.PrecacheModel("models/vj_hlr/gibs/agib1.mdl")
	util.PrecacheModel("models/vj_hlr/gibs/agib2.mdl")
	util.PrecacheModel("models/vj_hlr/gibs/agib3.mdl")
	util.PrecacheModel("models/vj_hlr/gibs/agib4.mdl")
	util.PrecacheModel("models/vj_hlr/gibs/agib5.mdl")
	util.PrecacheModel("models/vj_hlr/gibs/agib6.mdl")
	util.PrecacheModel("models/vj_hlr/gibs/agib7.mdl")
	util.PrecacheModel("models/vj_hlr/gibs/agib8.mdl")
	util.PrecacheModel("models/vj_hlr/gibs/agib9.mdl")
	util.PrecacheModel("models/vj_hlr/gibs/agib10.mdl")
	util.PrecacheModel("models/vj_hlr/gibs/flesh1.mdl")
	util.PrecacheModel("models/vj_hlr/gibs/flesh2.mdl")
	util.PrecacheModel("models/vj_hlr/gibs/flesh3.mdl")
	util.PrecacheModel("models/vj_hlr/gibs/flesh4.mdl")
	util.PrecacheModel("models/vj_hlr/gibs/hgib_b_bone.mdl")
	util.PrecacheModel("models/vj_hlr/gibs/hgib_b_gib.mdl")
	util.PrecacheModel("models/vj_hlr/gibs/hgib_guts.mdl")
	util.PrecacheModel("models/vj_hlr/gibs/hgib_hmeat.mdl")
	util.PrecacheModel("models/vj_hlr/gibs/hgib_lung.mdl")
	util.PrecacheModel("models/vj_hlr/gibs/hgib_skull.mdl")
	util.PrecacheModel("models/vj_hlr/gibs/hgib_legbone.mdl")
	util.PrecacheModel("models/vj_hlr/gibs/gib_hgrunt.mdl")
	util.PrecacheModel("models/vj_hlr/gibs/zombiegib.mdl")
	util.PrecacheModel("models/vj_hlr/gibs/islavegib.mdl")
	
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------ Convars ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	VJ.AddClientConVar("vj_hlr2_csniper_strict", 1, "Use strict laser pointer for the Combine Sniper")
	
	VJ.AddClientConVar("vj_hlr_sparkfx",0,"Allow spark effects to be created when a HLR1 bullet hits a metal surface")
	
	VJ.AddConVar("vj_hl2c_soldier_h",60)
	VJ.AddConVar("vj_hl2c_soldierprison_h",75)
	VJ.AddConVar("vj_hl2c_soldierelite_h",100)
	VJ.AddConVar("vj_hl2c_soldier_d",10)
	
	VJ.AddConVar("vj_hl2c_metrocop_h",50)
	VJ.AddConVar("vj_hl2c_elitecop_h",60)
	VJ.AddConVar("vj_hl2c_metrocop_d",10)
	
	VJ.AddConVar("vj_hl2r_rebel_h",50)
	VJ.AddConVar("vj_hl2r_rebel_d",10)
	
	-- Temp weapon hook!
	/*hook.Add("PlayerSpawn","VJ_HL1SWEPs_AutoSpawn",function(ply)
		if GetConVarNumber("hl1_sv_loadout") == 1 then
			ply:Give("weapon_hl1_357")
			ply:Give("weapon_hl1_glock")
			ply:Give("weapon_hl1_crossbow")
			ply:Give("weapon_hl1_egon")
			ply:Give("weapon_hl1_handgrenade")
			ply:Give("weapon_hl1_hornetgun")
			ply:Give("weapon_hl1_mp5")
			ply:Give("weapon_hl1_rpg")
			ply:Give("weapon_hl1_satchel")
			ply:Give("weapon_hl1_shotgun")
			//ply:Give("weapon_hl1_snark")
			ply:Give("weapon_hl1_gauss")
			ply:Give("weapon_hl1_tripmine")
		end
	end)*/
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------ Functions ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function VJ_HLR_Effect_PortalSpawn(pos, size, color)
	size = size or 1.5
	color = color or "77 210 130" -- TODO: Not implemented yet!
	local ent = ents.Create("env_sprite")
	ent:SetKeyValue("model","vj_hl/sprites/fexplo1.vmt")
	ent:SetKeyValue("GlowProxySize","2.0")
	ent:SetKeyValue("HDRColorScale","1.0")
	ent:SetKeyValue("rendercolor",color)
	ent:SetKeyValue("renderfx","14")
	ent:SetKeyValue("rendermode","3")
	ent:SetKeyValue("renderamt","255")
	ent:SetKeyValue("disablereceiveshadows","0")
	ent:SetKeyValue("mindxlevel","0")
	ent:SetKeyValue("maxdxlevel","0")
	ent:SetKeyValue("framerate","10.0")
	ent:SetKeyValue("spawnflags","0")
	ent:SetKeyValue("scale",""..size)
	ent:SetPos(pos)
	ent:Spawn()
	
	sound.Play("vj_hlr/fx/beamstart"..math.random(1,2)..".wav", pos, 85)
	return ent
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------ self.HLR_Type ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
/* Used to classify certain types of SNPCs
	"Headcrab"
	"Turret"
	"Police"
*/
-- !!!!!! DON'T TOUCH ANYTHING BELOW THIS !!!!!! -------------------------------------------------------------------------------------------------------------------------
	AddCSLuaFile(AutorunFile)
	VJ.AddAddonProperty(AddonName,AddonType)
else
	if (CLIENT) then
		chat.AddText(Color(0,200,200),PublicAddonName,
		Color(0,255,0)," was unable to install, you are missing ",
		Color(255,100,0),"VJ Base!")
	end
	timer.Simple(1,function()
		if not VJF then
			if (CLIENT) then
				VJF = vgui.Create("DFrame")
				VJF:SetTitle("ERROR!")
				VJF:SetSize(790,560)
				VJF:SetPos((ScrW()-VJF:GetWide())/2,(ScrH()-VJF:GetTall())/2)
				VJF:MakePopup()
				VJF.Paint = function()
					draw.RoundedBox(8,0,0,VJF:GetWide(),VJF:GetTall(),Color(200,0,0,150))
				end

				local VJURL = vgui.Create("DHTML",VJF)
				VJURL:SetPos(VJF:GetWide()*0.005, VJF:GetTall()*0.03)
				VJURL:Dock(FILL)
				VJURL:SetAllowLua(true)
				VJURL:OpenURL("https://sites.google.com/site/vrejgaming/vjbasemissing")
			elseif (SERVER) then
				timer.Create("VJBASEMissing",5,0,function() print("VJ Base is Missing! Download it from the workshop!") end)
			end
		end
	end)
end