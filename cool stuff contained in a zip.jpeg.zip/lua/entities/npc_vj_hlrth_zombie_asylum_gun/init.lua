AddCSLuaFile("shared.lua")
include('shared.lua')
/*-----------------------------------------------
	*** Copyright (c) 2012-2020 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/
ENT.Model = {"models/vj_hlr/sven/barney.mdl"} -- The game will pick a random model from the table when the SNPC is spawned | Add as many as you want
ENT.StartHealth = 90
ENT.HullType = HULL_HUMAN
ENT.VJC_Data = {
    ThirdP_Offset = Vector(10, 0, -30), -- The offset for the controller when the camera is in third person
    FirstP_Bone = "Bip01 Head", -- If left empty, the base will attempt to calculate a position for first person
    FirstP_Offset = Vector(4, 0, 0), -- The offset for the controller when the camera is in first person
}
---------------------------------------------------------------------------------------------------------------------------------------------
ENT.VJ_NPC_Class = {"CLASS_ZOMBIE"} -- NPCs with the same class with be allied to each other
ENT.BloodColor = "Red" -- The blood type, this will determine what it should use (decal, particle, etc.)
ENT.CustomBlood_Particle = {"vj_hl_blood_red"}
ENT.CustomBlood_Decal = {"VJ_HLR_Blood_Red"} -- Decals to spawn when it's damaged
ENT.HasBloodPool = false -- Does it have a blood pool?
ENT.HasMeleeAttack = false -- Should the SNPC have a melee attack?
ENT.Weapon_NoSpawnMenu = true -- If set to true, the NPC weapon setting in the spawnmenu will not be applied for this SNPC
ENT.DisableWeaponFiringGesture = true -- If set to true, it will disable the weapon firing gestures
ENT.MoveRandomlyWhenShooting = false -- Should it move randomly when shooting?
ENT.HasCallForHelpAnimation = false -- if true, it will play the call for help animation
ENT.AnimTbl_ShootWhileMovingRun = {ACT_RUN} -- Animations it will play when shooting while running | NOTE: Weapon may translate the animation that they see fit!
ENT.AnimTbl_ShootWhileMovingWalk = {ACT_RUN} -- Animations it will play when shooting while walking | NOTE: Weapon may translate the animation that they see fit!
ENT.DisableFootStepSoundTimer = true -- If set to true, it will disable the time system for the footstep sound code, allowing you to use other ways like model events
ENT.HasDeathAnimation = true -- Does it play an animation when it dies?
ENT.AnimTbl_TakingCover = {ACT_CROUCHIDLE} -- The animation it plays when hiding in a covered position, leave empty to let the base decide
ENT.AnimTbl_AlertFriendsOnDeath = {"vjseq_idle2"} -- Animations it plays when an ally dies that also has AlertFriendsOnDeath set to true
ENT.HasLostWeaponSightAnimation = true -- Set to true if you would like the SNPC to play a different animation when it has lost sight of the enemy and can't fire at it
ENT.HasItemDropsOnDeath = false -- Should it drop items on death?
ENT.HasOnPlayerSight = true -- Should do something when it sees the enemy? Example: Play a sound
ENT.CombatFaceEnemy = false -- If enemy is exists and is visible
ENT.HasIdleDialogueSounds = false -- If set to false, it won't play the idle dialogue sounds
ENT.HasIdleDialogueAnswerSounds = false -- If set to false, it won't play the idle dialogue answer sounds
ENT.IdleDialogueCanTurn = false -- If set to false, it won't turn when a dialogue occurs
	-- ====== Flinching Code ====== --
ENT.CanFlinch = 1 -- 0 = Don't flinch | 1 = Flinch at any damage | 2 = Flinch only from certain damages
ENT.AnimTbl_Flinch = {ACT_SMALL_FLINCH} -- If it uses normal based animation, use this
ENT.HasHitGroupFlinching = true -- It will flinch when hit in certain hitgroups | It can also have certain animations to play in certain hitgroups
ENT.HitGroupFlinching_Values = {{HitGroup = {HITGROUP_LEFTARM}, Animation = {ACT_FLINCH_LEFTARM}},{HitGroup = {HITGROUP_RIGHTARM}, Animation = {ACT_FLINCH_RIGHTARM}},{HitGroup = {HITGROUP_LEFTLEG}, Animation = {ACT_FLINCH_LEFTLEG}},{HitGroup = {HITGROUP_RIGHTLEG}, Animation = {ACT_FLINCH_RIGHTLEG}}}
	-- ====== Sound File Paths ====== --
-- Leave blank if you don't want any sounds to play
ENT.SoundTbl_FootStep = {"vj_hlr/pl_step1.wav","vj_hlr/pl_step2.wav","vj_hlr/pl_step3.wav","vj_hlr/pl_step4.wav"}

/*
-- Can't follow
vj_hlr/hl1_npc/barney/ba_stop0.wav
vj_hlr/hl1_npc/barney/ba_stop1.wav
vj_hlr/hl1_npc/barney/stop1.wav
vj_hlr/hl1_npc/barney/stophere.wav

vj_hlr/hl1_npc/barney/ba_internet.wav
vj_hlr/hl1_npc/barney/ba_attacking0.wav
vj_hlr/hl1_npc/barney/ba_attacking2.wav
vj_hlr/hl1_npc/barney/ba_becareful0.wav
vj_hlr/hl1_npc/barney/ba_button0.wav
vj_hlr/hl1_npc/barney/ba_button1.wav
vj_hlr/hl1_npc/barney/ba_canal_death1.wav
vj_hlr/hl1_npc/barney/ba_canal_wound1.wav
vj_hlr/hl1_npc/barney/ba_cure0.wav
vj_hlr/hl1_npc/barney/ba_cure1.wav
vj_hlr/hl1_npc/barney/ba_docprotect0.wav
vj_hlr/hl1_npc/barney/ba_docprotect1.wav
vj_hlr/hl1_npc/barney/ba_docprotect2.wav
vj_hlr/hl1_npc/barney/ba_docprotect3.wav
vj_hlr/hl1_npc/barney/ba_door0.wav
vj_hlr/hl1_npc/barney/ba_door1.wav
vj_hlr/hl1_npc/barney/ba_duty.wav
vj_hlr/hl1_npc/barney/ba_generic2.wav
vj_hlr/hl1_npc/barney/ba_help0.wav
-- vj_hlr/hl1_npc/barney/ba_ht01_01.wav ---> vj_hlr/hl1_npc/barney/ba_ht06_01.wav
-- vj_hlr/hl1_npc/barney/ba_ht06_04.wav ---> vj_hlr/hl1_npc/barney/ba_ht06_10.wav
--vj_hlr/hl1_npc/barney/ba_ht07_01.wav ---> vj_hlr/hl1_npc/barney/ba_ht08_03.wav
vj_hlr/hl1_npc/barney/ba_idle2.wav
vj_hlr/hl1_npc/barney/ba_idle5.wav
vj_hlr/hl1_npc/barney/ba_idle6.wav
vj_hlr/hl1_npc/barney/ba_kill1.wav
vj_hlr/hl1_npc/barney/ba_kill2.wav
vj_hlr/hl1_npc/barney/ba_lead0.wav
vj_hlr/hl1_npc/barney/ba_lead1.wav
vj_hlr/hl1_npc/barney/ba_lead2.wav
vj_hlr/hl1_npc/barney/ba_mad2.wav
vj_hlr/hl1_npc/barney/ba_ok0.wav
vj_hlr/hl1_npc/barney/ba_opgate.wav
vj_hlr/hl1_npc/barney/ba_plfear0.wav
-- vj_hlr/hl1_npc/barney/ba_pok0.wav ---> vj_hlr/hl1_npc/barney/ba_security2_nopass.wav
vj_hlr/hl1_npc/barney/ba_security2_range1.wav
vj_hlr/hl1_npc/barney/ba_security2_range2.wav
vj_hlr/hl1_npc/barney/ba_shot0.wav
vj_hlr/hl1_npc/barney/ba_stare2.wav
vj_hlr/hl1_npc/barney/ba_stare3.wav
-- vj_hlr/hl1_npc/barney/c1a0_ba_button.wav ---> vj_hlr/hl1_npc/barney/c1a2_ba_2zomb.wav
vj_hlr/hl1_npc/barney/c1a2_ba_bullsquid.wav
vj_hlr/hl1_npc/barney/c1a2_ba_climb.wav
vj_hlr/hl1_npc/barney/c1a2_ba_slew.wav
vj_hlr/hl1_npc/barney/c1a2_ba_surface.wav
vj_hlr/hl1_npc/barney/c1a2_ba_top.wav
-- vj_hlr/hl1_npc/barney/c1a4_ba_wisp.wav ---> vj_hlr/hl1_npc/barney/c3a2_ba_stay.wav
vj_hlr/hl1_npc/barney/checkwounds.wav
vj_hlr/hl1_npc/barney/imdead.wav
vj_hlr/hl1_npc/barney/killme.wav
vj_hlr/hl1_npc/barney/leavealone.wav
vj_hlr/hl1_npc/barney/of1a5_ba02.wav
vj_hlr/hl1_npc/barney/of6a4_ba01.wav
vj_hlr/hl1_npc/barney/of6a4_ba02.wav
vj_hlr/hl1_npc/barney/of6a4_ba03.wav
vj_hlr/hl1_npc/barney/of6a4_ba04.wav
vj_hlr/hl1_npc/barney/openfire.wav
vj_hlr/hl1_npc/barney/realbadwound.wav
vj_hlr/hl1_npc/barney/sir.wav
vj_hlr/hl1_npc/barney/soldier.wav
vj_hlr/hl1_npc/barney/youneedmedic.wav
*/

ENT.GeneralSoundPitch1 = 100

-- Custom
ENT.Security_NextMouthMove = 0
ENT.Security_NextMouthDistance = 0
ENT.Security_GunHolstered = true
ENT.Security_SwitchedIdle = false
ENT.Security_Type = 0
ENT.Otis_Helmet = false
ENT.Barney_Helmet = false
ENT.Boobs_Flat = false
ENT.Boobs_Medium = false
ENT.Boobs_Big = false
	-- 0 = Security Guard
	-- 1 = Otis
	-- 2 = Alpha Security Guard
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:Security_CustomOnInitialize()
	self:SetMaterial("Invisible")
	self:DrawShadow(false)
	self.SoundTbl_Idle = {"vj_hlr/th_npc/hunger/hungerbarney/ba_kill1.wav","vj_hlr/th_npc/hunger/hungerbarney/ba_kill2.wav","vj_hlr/th_npc/hunger/hungerbarney/ba_kill3.wav","vj_hlr/th_npc/hunger/hungerbarney/ba_kill4.wav","vj_hlr/th_npc/hunger/hungerbarney/ba_kill5.wav"}
	self.SoundTbl_CombatIdle = {"vj_hlr/th_npc/hunger/hungerbarney/ba_kill1.wav","vj_hlr/th_npc/hunger/hungerbarney/ba_kill2.wav","vj_hlr/th_npc/hunger/hungerbarney/ba_kill3.wav","vj_hlr/th_npc/hunger/hungerbarney/ba_kill4.wav","vj_hlr/th_npc/hunger/hungerbarney/ba_kill5.wav"}
	self.SoundTbl_Investigate = {""}
	self.SoundTbl_Alert = {"vj_hlr/th_npc/hunger/hungerbarney/ba_kill1.wav"}
	self.SoundTbl_CallForHelp = {""}
	self.SoundTbl_Suppressing = {""}
	self.SoundTbl_OnGrenadeSight = {""}
	self.SoundTbl_OnKilledEnemy = {"vj_hlr/th_npc/hunger/hungerbarney/ba_kill1.wav","vj_hlr/th_npc/hunger/hungerbarney/ba_kill2.wav","vj_hlr/th_npc/hunger/hungerbarney/ba_kill3.wav","vj_hlr/th_npc/hunger/hungerbarney/ba_kill4.wav","vj_hlr/th_npc/hunger/hungerbarney/ba_kill5.wav"}
	self.SoundTbl_AllyDeath = {""}
	self.SoundTbl_Pain = {"vj_hlr/th_npc/hunger/hungerbarney/ba_pain1.wav","vj_hlr/th_npc/hunger/hungerbarney/ba_pain2.wav","vj_hlr/th_npc/hunger/hungerbarney/ba_pain3.wav"}
	self.SoundTbl_Death = {"vj_hlr/th_npc/hunger/hungerbarney/ba_die1.wav","vj_hlr/th_npc/hunger/hungerbarney/ba_die2.wav","vj_hlr/th_npc/hunger/hungerbarney/ba_die3.wav"}

	self.AnimTbl_Death = {ACT_DIEBACKWARD,ACT_DIEFORWARD,ACT_DIE_GUTSHOT,ACT_DIE_HEADSHOT,ACT_DIESIMPLE} -- Death Animations
	
	self:Give("weapon_vj_hlr1_glock17")
	self:GetActiveWeapon().Primary.Damage = 2
	self.PropGun = ents.Create("obj_warlord_gun")
	self.PropGun:SetModel("models/vj_hlr/theyhunger/barney_hand.mdl")
	self.PropGun:Spawn()
	self.PropGun:DrawShadow(false)
	self.PropGun:SetParent(self)
	self.PropGun:SetSubMaterial(0, "models/theyhungernew/bigote2")
	self.PropGun:SetSubMaterial(5, "models/theyhungernew/newcophatleft2")
	self.PropGun:SetSubMaterial(6, "models/theyhungernew/newcophatfront2zo")
	self.PropGun:SetSubMaterial(7, "models/theyhungernew/new_faceside2zo")
	self.PropGun:SetSubMaterial(8, "models/theyhungernew/new_face2zo")
	self.PropGun:SetSubMaterial(9, "models/theyhungernew/new_earszo")
	self.PropGun:SetSubMaterial(13, "models/theyhungernew/BX_Arm2zo")
	self.PropGun:SetSubMaterial(15, "models/theyhungernew/BX_Hand1zo")
	self.PropGun:SetSubMaterial(17, "models/theyhungernew/BX_Front2zo")
	self.PropGun:SetSubMaterial(18, "models/theyhungernew/BX_Back2zo")
	self.PropGun:SetSubMaterial(19, "models/theyhungernew/PLACA2")
	self.PropGun:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
	self.Barney_Helmet = false
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnInitialize()
	self:SetCollisionBounds(Vector(13, 13, 76), Vector(-13, -13, 0))
	self:SetBodygroup(1,0)
	
	if self:GetModel() == "models/vj_hlr/sven/barney.mdl" then // Already the default
		self.Security_Type = 0
	elseif self:GetModel() == "models/vj_hlr/sven/otis.mdl" then
		self.Security_Type = 1
	elseif self:GetModel() == "models/vj_hlr/hla/barney.mdl" then
		self.Security_Type = 2
	end
	self:Security_CustomOnInitialize()
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnAcceptInput(key, activator, caller, data)
	//print(key)
	if key == "step" then
		self:FootStepSoundCode()
	end
	if key == "shoot" then
		local wep = self:GetActiveWeapon()
		if IsValid(wep) then
			wep:NPCShoot_Primary(ShootPos,ShootDir)
		end
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnThink()
	if self.Security_Type != 2 then -- If it's regular or Otis...
		if CurTime() < self.Security_NextMouthMove then
			if self.Security_NextMouthDistance == 0 then
				self.Security_NextMouthDistance = math.random(10,70)
			else
				self.Security_NextMouthDistance = 0
			end
			self:SetPoseParameter("m",self.Security_NextMouthDistance)
		else
			self:SetPoseParameter("m",0)
		end
		-- For guarding
		if self.IsGuard == true && self.Security_GunHolstered == true && !IsValid(self:GetEnemy()) then
			if self.Security_SwitchedIdle == false then
				self.Security_SwitchedIdle = true
				self.AnimTbl_IdleStand = {ACT_GET_DOWN_STAND, ACT_GET_UP_STAND}
			end
		elseif self.Security_SwitchedIdle == true then
			self.Security_SwitchedIdle = false
			self.AnimTbl_IdleStand = {ACT_IDLE}
		end
	elseif IsValid(self:GetActiveWeapon()) then -- Alpha Security Guard can't reload!
		self:GetActiveWeapon():SetClip1(999)
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:OnPlayCreateSound(SoundData,SoundFile)
	self.Security_NextMouthMove = CurTime() + SoundDuration(SoundFile)
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnAlert(argent)
	if math.random(1,2) == 1 then
		if self.Security_Type == 0 then
			if argent:GetClass() == "npc_vj_hlr1_bullsquid" then
				self:PlaySoundSystem("Alert", {"vj_hlr/hl1_npc/barney/c1a4_ba_octo1.wav"})
				self.NextAlertSoundT = CurTime() + math.Rand(self.NextSoundTime_Alert1,self.NextSoundTime_Alert2)
			elseif argent.IsVJBaseSNPC_Creature == true then
				self:PlaySoundSystem("Alert", {"vj_hlr/hl1_npc/barney/diebloodsucker.wav"})
				self.NextAlertSoundT = CurTime() + math.Rand(self.NextSoundTime_Alert1,self.NextSoundTime_Alert2)
			end
		elseif self.Security_Type == 1 && argent.IsVJBaseSNPC_Creature == true then
			self:PlaySoundSystem("Alert", {"vj_hlr/hl1_npc/otis/aliens.wav"})
			self.NextAlertSoundT = CurTime() + math.Rand(self.NextSoundTime_Alert1,self.NextSoundTime_Alert2)
		end
	end
	
	if self.Security_GunHolstered == true then
		self:Security_UnHolsterGun()
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:Security_UnHolsterGun()
	self:StopMoving()
	self:VJ_ACT_PLAYACTIVITY(ACT_ARM, true, false, true)
	self.Security_GunHolstered = false
	timer.Simple(0.55,function() if IsValid(self) then self.PropGun:SetBodygroup(1,1) end end)
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnThink_AIEnabled()
	if self.Dead == true then return end
	if self.Security_GunHolstered == true && IsValid(self:GetEnemy()) then
		self:Security_UnHolsterGun()
	elseif self.Security_GunHolstered == false && !IsValid(self:GetEnemy()) && self.TimeSinceLastSeenEnemy > 5 && self.IsReloadingWeapon == false then
		self:VJ_ACT_PLAYACTIVITY(ACT_DISARM, true, false, true)
		self.Security_GunHolstered = true
		timer.Simple(1.5,function() if IsValid(self) && !IsValid(self:GetEnemy()) then self.PropGun:SetBodygroup(1,0) end end)
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnIsAbleToShootWeapon()
	if self.Security_GunHolstered == true then return false end
	return true
end
local vec = Vector(0,0,0)
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnTakeDamage_BeforeImmuneChecks(dmginfo,hitgroup)
	if hitgroup == HITGROUP_GEAR && self.Security_Type == 2 && dmginfo:GetDamagePosition() != vec then
		local rico = EffectData()
		rico:SetOrigin(dmginfo:GetDamagePosition())
		rico:SetScale(4) -- Size
		rico:SetMagnitude(math.random(1,2)) -- Effect type | 1 = Animated | 2 = Basic
		util.Effect("VJ_HLR_Rico",rico)
	end
	if hitgroup == HITGROUP_GEAR && self.Otis_Helmet == false && self.Security_Type == 1 && dmginfo:GetDamagePosition() != vec then
		dmginfo:ScaleDamage(2.0)
	end
	if hitgroup == HITGROUP_GEAR && self.Otis_Helmet == true && self.Security_Type == 1 && dmginfo:GetDamagePosition() != vec then
		local rico = EffectData()
		rico:SetOrigin(dmginfo:GetDamagePosition())
		rico:SetScale(4) -- Size
		rico:SetMagnitude(math.random(1,2)) -- Effect type | 1 = Animated | 2 = Basic
		util.Effect("VJ_HLR_Rico",rico)
	end
	if hitgroup == HITGROUP_GEAR && self.Barney_Helmet == true && self.Security_Type == 0 && dmginfo:GetDamagePosition() != vec then
		local rico = EffectData()
		rico:SetOrigin(dmginfo:GetDamagePosition())
		rico:SetScale(4) -- Size
		rico:SetMagnitude(math.random(1,2)) -- Effect type | 1 = Animated | 2 = Basic
		util.Effect("VJ_HLR_Rico",rico)
	end
	if hitgroup == HITGROUP_GEAR && self.Barney_Helmet == false && self.Security_Type == 0 && dmginfo:GetDamagePosition() != vec then
		dmginfo:ScaleDamage(2.0)
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:SetUpGibesOnDeath(dmginfo,hitgroup)
	self.HasDeathSounds = false
	if self.HasGibDeathParticles == true then
		local bloodeffect = EffectData()
		bloodeffect:SetOrigin(self:GetPos() +self:OBBCenter())
		bloodeffect:SetColor(VJ_Color2Byte(Color(130,19,10)))
		bloodeffect:SetScale(120)
		util.Effect("VJ_Blood1",bloodeffect)
		
		local bloodspray = EffectData()
		bloodspray:SetOrigin(self:GetPos())
		bloodspray:SetScale(8)
		bloodspray:SetFlags(3)
		bloodspray:SetColor(0)
		util.Effect("bloodspray",bloodspray)
		util.Effect("bloodspray",bloodspray)
	end
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/flesh1.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,40))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/flesh2.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,40))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/flesh3.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,40))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/flesh4.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,40))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/hgib_b_bone.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,50))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/hgib_b_gib.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,40))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/hgib_guts.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,40))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/hgib_hmeat.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,45))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/hgib_lung.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,45))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/hgib_skull.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,60))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/hgib_legbone.mdl",{BloodDecal="VJ_HLR_Blood_Red",Pos=self:LocalToWorld(Vector(0,0,15))})
	return true -- Return to true if it gibbed!
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomGibOnDeathSounds(dmginfo,hitgroup)
	VJ_EmitSound(self, "vj_gib/default_gib_splat.wav", 90, math.random(100,100))
	return false
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomDeathAnimationCode(dmginfo, hitgroup)
	self:DropWeaponOnDeathCode(dmginfo, hitgroup)
	self:CustomOnDeath_BeforeCorpseSpawned(dmginfo, hitgroup)
	if IsValid(self:GetActiveWeapon()) then self:GetActiveWeapon():Remove() end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnDeath_BeforeCorpseSpawned(dmginfo,hitgroup)
	self.PropGun:SetBodygroup(1,2)
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnDeath_AfterCorpseSpawned(dmginfo,hitgroup)
	self.Corpse:SetMaterial("Invisible")
	self.Corpse:DrawShadow(false)
	self.PropGun = ents.Create("obj_warlord_gun")
	self.PropGun:SetModel("models/vj_hlr/theyhunger/barney_hand.mdl")
	self.PropGun:Spawn()
	self.PropGun:DrawShadow(false)
	self.PropGun:SetParent(self.Corpse)
	self.PropGun:SetBodygroup(1,2)
	self.PropGun:SetSubMaterial(0, "models/theyhungernew/bigote2")
	self.PropGun:SetSubMaterial(5, "models/theyhungernew/newcophatleft2")
	self.PropGun:SetSubMaterial(6, "models/theyhungernew/newcophatfront2zo")
	self.PropGun:SetSubMaterial(7, "models/theyhungernew/new_faceside2zo")
	self.PropGun:SetSubMaterial(8, "models/theyhungernew/new_face2zo")
	self.PropGun:SetSubMaterial(9, "models/theyhungernew/new_earszo")
	self.PropGun:SetSubMaterial(13, "models/theyhungernew/BX_Arm2zo")
	self.PropGun:SetSubMaterial(15, "models/theyhungernew/BX_Hand1zo")
	self.PropGun:SetSubMaterial(17, "models/theyhungernew/BX_Front2zo")
	self.PropGun:SetSubMaterial(18, "models/theyhungernew/BX_Back2zo")
	self.PropGun:SetSubMaterial(19, "models/theyhungernew/PLACA2")
	self.PropGun:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
	self.Barney_Helmet = false
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnDropWeapon_AfterWeaponSpawned(dmginfo,hitgroup,GetWeapon)
	GetWeapon.WorldModel_Invisible = false
	GetWeapon:SetNWBool("VJ_WorldModel_Invisible",false)
end
/*-----------------------------------------------
	*** Copyright (c) 2012-2020 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/