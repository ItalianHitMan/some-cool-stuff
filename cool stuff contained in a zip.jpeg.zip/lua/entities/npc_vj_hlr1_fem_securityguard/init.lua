AddCSLuaFile("shared.lua")
include('shared.lua')
/*-----------------------------------------------
	*** Copyright (c) 2012-2020 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/
ENT.Model = {"models/vj_hlr/hl1/barney.mdl"} -- The game will pick a random model from the table when the SNPC is spawned | Add as many as you want
ENT.VJC_Data = {
    ThirdP_Offset = Vector(10, 0, -30), -- The offset for the controller when the camera is in third person
    FirstP_Bone = "Bip01 Head", -- If left empty, the base will attempt to calculate a position for first person
    FirstP_Offset = Vector(4, 0, 5), -- The offset for the controller when the camera is in first person
	FirstP_ShrinkBone = false, -- Should the bone shrink? Useful if the bone is obscuring the player's view
}
ENT.StartHealth = 90

/*
-- cant follow
vj_hlr/hl1_npc/otis/behind.wav

vj_hlr/hl1_npc/otis/breath.wav
vj_hlr/hl1_npc/otis/leavealone.wav
vj_hlr/hl1_npc/otis/of1a1_ot01.wav
vj_hlr/hl1_npc/otis/of1a1_ot02.wav
vj_hlr/hl1_npc/otis/of2a6_ot01.wav
vj_hlr/hl1_npc/otis/of3a2_ot01.wav
vj_hlr/hl1_npc/otis/of6a3_ot01.wav
*/
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:Security_CustomOnInitialize()
	self:DrawShadow(false)
	self:SetMaterial("Invisible")
	self.PropGun = ents.Create("obj_warlord_gun")
	self.PropGun:SetModel("models/barniel/barniel_as.mdl")
	self.PropGun:Spawn()
	self.PropGun:SetParent(self)
	self.PropGun:SetBodygroup(1,0)
	self.PropGun:SetSubMaterial(18 ,"models/chrome/barney/bx_chrome1")
	self.PropGun:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
	self.SoundTbl_Idle = {"barniel/humm.wav","barniel/somethingmoves.wav","barniel/movietv.wav","barniel/badfeeling.wav"}
	self.SoundTbl_IdleDialogue = {"barniel/slimything.wav","barniel/thinking.wav","barniel/whatsgoingon.wav","barniel/rightway.wav","barniel/drinktopside.wav"}
	self.SoundTbl_IdleDialogueAnswer = {"barniel/dontagree.wav","barniel/yessir.wav","barniel/nosir.wav","barniel/dontknow.wav"}
	self.SoundTbl_CombatIdle = {""}
	self.SoundTbl_FollowPlayer = {"barniel/teamup1.wav","barniel/teamup2.wav","barniel/yessir.wav","barniel/rightway.wav"}
	self.SoundTbl_UnFollowPlayer = {"barniel/waitin.wav","barniel/stop1.wav","barniel/seelater.wav","barniel/seeya.wav","barniel/bn_becarefull.wav"}
	self.SoundTbl_OnPlayerSight = {"barniel/hi.wav"}
	self.SoundTbl_Investigate = {"barniel/bn_becarefull.wav","barniel/hearsomething.wav"}
	self.SoundTbl_Alert = {"barniel/openfire.wav","barniel/bn_attack1.wav","barniel/aimforhead.wav","barniel/bn_carefull.wav","barniel/bn_becarefull.wav"}
	self.SoundTbl_CallForHelp = {""}
	self.SoundTbl_BecomeEnemyToPlayer = {"barniel/bn_iwish.wav","barniel/bn_tomb.wav","barniel/bn_somuch.wav","barniel/bn_dontmake.wav","barniel/bn_uwish.wav","barniel/bn_endline.wav"}
	self.SoundTbl_Suppressing = {""}
	self.SoundTbl_OnGrenadeSight = {"barniel/bn_becarefull.wav"}
	self.SoundTbl_OnKilledEnemy = {"barniel/bn_seethat.wav","barniel/diegreenthing.wav","barniel/bn_gotone.wav","barniel/bn_firepl.wav","barniel/bn_another.wav"}
	self.SoundTbl_AllyDeath = {""}
	self.SoundTbl_Pain = {"barniel/imhit.wav","barniel/hitbad.wav","vj_hlr/hl1_npc/colette/colette_pain0.wav","vj_hlr/hl1_npc/colette/colette_pain1.wav","vj_hlr/hl1_npc/colette/colette_pain2.wav","vj_hlr/hl1_npc/colette/colette_pain3.wav"}
	self.SoundTbl_DamageByPlayer = {"barniel/bn_dontdothat.wav","barniel/bn_stepoff.wav","barniel/bn_friends.wav"}
	self.SoundTbl_Death = {"vj_hlr/hl1_npc/colette/colette_die0.wav","vj_hlr/hl1_npc/colette/colette_die1.wav","vj_hlr/hl1_npc/colette/colette_die2.wav"}
		local randboob = math.random(2,2)
		if randboob == 1 then
		self.Boobs_Flat = true
		self.PropGun:ManipulateBoneScale(10, Vector(1,0.9,1))
		end
		if randboob == 2 then
		self.Boobs_Medium = true
		end
		if randboob == 3 then
		self.Boobs_Huge = true
		self.PropGun:ManipulateBoneScale(10, Vector(1.17,1.2,1.1))
		end
		if randboob == 4 then
		self.Boobs_Medium = true
		end
		local randmod = math.random(1,3)
		if randmod == 1 then
		self.Otis_Helmet = true
		end
		if randmod == 2 then
		self.Otis_Helmet = true
		end
		if randmod == 3 then
		self.Otis_Helmet = false
		self.PropGun:SetSubMaterial(18 ,"Invisible")
		self.PropGun:SetSubMaterial(17 ,"Invisible")
		self.PropGun:SetSubMaterial(19 ,"Invisible")
		end
	
	self.AnimTbl_Death = {ACT_DIEBACKWARD,ACT_DIEFORWARD,ACT_DIE_GUTSHOT,ACT_DIE_HEADSHOT,ACT_DIESIMPLE} -- Death Animations
	self:Give("weapon_vj_hlr1_glock17")
end

// vj_hlr/hl1_npc/otis/aliens.wav
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnDeath_BeforeCorpseSpawned(dmginfo,hitgroup)
	self.PropGun:SetBodygroup(1,2)
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnAlert(argent)
	if math.random(1,2) == 1 then
		if self.Security_Type == 0 then
			if argent:GetClass() == "npc_vj_hlr1_bullsquid" then
				self:PlaySoundSystem("Alert", {"barniel/diegreenthing.wav"})
				self.NextAlertSoundT = CurTime() + math.Rand(self.NextSoundTime_Alert1,self.NextSoundTime_Alert2)
			elseif argent.IsVJBaseSNPC_Creature == true then
				self:PlaySoundSystem("Alert", {"barniel/diegreenthing.wav"})
				self.NextAlertSoundT = CurTime() + math.Rand(self.NextSoundTime_Alert1,self.NextSoundTime_Alert2)
			end
		elseif self.Security_Type == 1 && argent.IsVJBaseSNPC_Creature == true then
			self:PlaySoundSystem("Alert", {"barniel/diegreenthing.wav"})
			self.NextAlertSoundT = CurTime() + math.Rand(self.NextSoundTime_Alert1,self.NextSoundTime_Alert2)
		end
	end
	
	if self.Security_GunHolstered == true then
		self:Security_UnHolsterGun()
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:Security_UnHolsterGun()
	self:StopMoving()
	self:VJ_ACT_PLAYACTIVITY(ACT_ARM, true, false, true)
	self.Security_GunHolstered = false
	timer.Simple(0.55,function() if IsValid(self) then self.PropGun:SetBodygroup(1,1) end end)
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnThink()
	self:SetNoDraw(true)
	self:DrawShadow(false)
	self:RemoveAllDecals()
	if self.Security_Type != 2 then -- If it's regular or Otis...
		if CurTime() < self.Security_NextMouthMove then
			if self.Security_NextMouthDistance == 0 then
				self.Security_NextMouthDistance = math.random(10,70)
			else
				self.Security_NextMouthDistance = 0
			end
			self:SetPoseParameter("m",self.Security_NextMouthDistance)
		else
			self:SetPoseParameter("m",0)
		end
		-- For guarding
		if self.IsGuard == true && self.Security_GunHolstered == true && !IsValid(self:GetEnemy()) then
			if self.Security_SwitchedIdle == false then
				self.Security_SwitchedIdle = true
				self.AnimTbl_IdleStand = {ACT_GET_DOWN_STAND, ACT_GET_UP_STAND}
			end
		elseif self.Security_SwitchedIdle == true then
			self.Security_SwitchedIdle = false
			self.AnimTbl_IdleStand = {ACT_IDLE}
		end
	elseif IsValid(self:GetActiveWeapon()) then -- Alpha Security Guard can't reload!
		self:GetActiveWeapon():SetClip1(999)
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnThink_AIEnabled()
	if self.Dead == true then return end
	if self.Security_GunHolstered == true && IsValid(self:GetEnemy()) then
		self:Security_UnHolsterGun()
	elseif self.Security_GunHolstered == false && !IsValid(self:GetEnemy()) && self.TimeSinceLastSeenEnemy > 5 && self.IsReloadingWeapon == false then
		self:VJ_ACT_PLAYACTIVITY(ACT_DISARM, true, false, true)
		self.Security_GunHolstered = true
		timer.Simple(1.5,function() if IsValid(self) && !IsValid(self:GetEnemy()) then self.PropGun:SetBodygroup(1,0) end end)
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnDeath_AfterCorpseSpawned(dmginfo,hitgroup)
	self.Corpse:RemoveAllDecals()
	self.Corpse:DrawShadow(false)
	self.Corpse:SetMaterial("Invisible")
	self.PropGun = ents.Create("obj_warlord_gun")
	self.PropGun:SetModel("models/barniel/barniel_as.mdl")
	self.PropGun:Spawn()
	self.PropGun:SetParent(self.Corpse)
	self.PropGun:SetBodygroup(1,2)
	self.PropGun:SetSubMaterial(18 ,"models/chrome/barney/bx_chrome1")
	self.PropGun:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
	if self.Boobs_Flat == true then
	self.PropGun:ManipulateBoneScale(10, Vector(1,0.9,1.1))
	end
	if self.Boobs_Huge == true then
	self.PropGun:ManipulateBoneScale(10, Vector(1.17,1.2,1.1))
	end
	if self.Otis_Helmet == false then
		self.PropGun:SetSubMaterial(18 ,"Invisible")
		self.PropGun:SetSubMaterial(17 ,"Invisible")
		self.PropGun:SetSubMaterial(19 ,"Invisible")
	end
end
/*-----------------------------------------------
	*** Copyright (c) 2012-2020 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/