AddCSLuaFile("shared.lua")
include('shared.lua')
/*-----------------------------------------------
	*** Copyright (c) 2012-2017 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/
ENT.Model = {"models/vj_hlr/hl2old/poison_zombie.mdl"} -- The game will pick a random model from the table when the SNPC is spawned | Add as many as you want
ENT.StartHealth = 275
ENT.HullType = HULL_HUMAN
---------------------------------------------------------------------------------------------------------------------------------------------
ENT.VJ_NPC_Class = {"CLASS_ZOMBIE"} -- NPCs with the same class with be allied to each other
ENT.BloodColor = "Yellow" -- The blood type, this will determine what it should use (decal, particle, etc.)
ENT.CustomBlood_Particle = {"vj_hl_blood_yellow"}
ENT.CustomBlood_Decal = {"VJ_HLR_Blood_Yellow"} -- Decals to spawn when it's damaged
ENT.HasBloodPool = false -- Does it have a blood pool?
ENT.HasMeleeAttack = true -- Should the SNPC have a melee attack?
ENT.AnimTbl_MeleeAttack = {ACT_MELEE_ATTACK1} -- Melee Attack Animations
ENT.MeleeAttackDistance = 32 -- How close does it have to be until it attacks?
ENT.MeleeAttackDamageDistance = 60 -- How far does the damage go?
ENT.MeleeAttackDamage = 18
ENT.TimeUntilMeleeAttackDamage = 0.5
ENT.DisableFootStepSoundTimer = true -- If set to true, it will disable the time system for the footstep sound code, allowing you to use other ways like model events
ENT.HasExtraMeleeAttackSounds = true -- Set to true to use the extra melee attack sounds
ENT.GeneralSoundPitch1 = 100
ENT.HasDeathAnimation = true -- Does it play an animation when it dies?
ENT.AnimTbl_Death = {ACT_DIEBACKWARD,ACT_DIESIMPLE}
ENT.DeathCorpseModel = {"models/vj_hlr/hl1/zombie.mdl"}
	-- ====== Flinching Code ====== --
ENT.CanFlinch = 1 -- 0 = Don't flinch | 1 = Flinch at any damage | 2 = Flinch only from certain damages
ENT.AnimTbl_Flinch = {ACT_SMALL_FLINCH} -- If it uses normal based animation, use this
	-- ====== Sound File Paths ====== --
-- Leave blank if you don't want any sounds to play
ENT.SoundTbl_Idle = {"vj_hlr/hl2old/pzombie/pz_idle2.wav","vj_hlr/hl2old/pzombie/pz_idle3.wav"}
ENT.SoundTbl_Breath = {"vj_hlr/hl2old/pzombie/pz_breathe_loop1.wav"}
ENT.SoundTbl_Alert = {"vj_hlr/hl2old/pzombie/pz_alert1.wav","vj_hlr/hl2old/pzombie/pz_alert2.wav"}
ENT.SoundTbl_BeforeMeleeAttack = {"npc/zombie_poison/pz_warn1.wav","npc/zombie_poison/pz_warn2.wav"}
ENT.SoundTbl_Pain = {"vj_hlr/hl2old/pzombie/pz_pain1.wav","vj_hlr/hl2old/pzombie/pz_pain2.wav","vj_hlr/hl2old/pzombie/pz_pain3.wav"}
ENT.SoundTbl_Death = {"vj_hlr/hl2old/pzombie/pz_die1.wav","vj_hlr/hl2old/pzombie/pz_die2.wav"}
ENT.SoundTbl_Warn = {"vj_hlr/hl2old/pzombie/pz_warn2.wav"}
ENT.SoundTbl_Throw = {"npc/zombie_poison/pz_throw2.wav","npc/zombie_poison/pz_throw3.wav"}
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnInitialize()
	self:SetSubMaterial(0, "models/hl_resurgence/hl1/bodyarmorfnt")
	self:SetSubMaterial(1, "models/hl_resurgence/hl1/pantfront")
	self:SetSubMaterial(4, "models/hl_resurgence/hl1/bodyarmorfnt")
	self:SetSubMaterial(5, "models/hl_resurgence/hl1/pantfront")
	self:SetSubMaterial(7, "models/hl_resurgence/hl1/pantfront")
	self:SetSubMaterial(8, "models/hl_resurgence/hl1/pantfront")
	self:SetSubMaterial(9, "models/hl_resurgence/hl1/bootside")
	self:SetSubMaterial(10, "models/hl_resurgence/hl1/pantfront")
	self:SetSubMaterial(11, "models/hl_resurgence/hl1/pantfront")
	self:SetSkin(math.random(0,10))
	self:SetBodygroup(1,3)
	self:SetCollisionBounds(Vector(22,22,60), Vector(-22,-22,0))
	self.BlackHeadcrabs = 3
	self.NextThrowT = 0
	self.CustomRunActivites = {VJ_SequenceToActivity(self,"FireWalk")}
	self.IsSlumped = false
	self.SlumpAnimation = "slump_a"
	self.SlumpRise = "slumprise_a"
	if self.Slump then
		self.IsSlumped = true
		self.VJ_NoTarget = true
		self.SoundTbl_Breath = {}
		self.SoundTbl_Idle = {}
		self.AnimTbl_IdleStand = {self.SlumpAnimation}
		self.SightDistance = 140
		self.SightAngle = 180
		self.MovementType = VJ_MOVETYPE_STATIONARY
		self.CanTurnWhileStationary = false
		self.HasMeleeAttack = false
		self.HasRangeAttack = false
		self.HasLeapAttack = false
		self.CanFlinch = 0
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:UnSlump()
	self.IsSlumped = false
	self.AnimTbl_IdleStand = {ACT_IDLE}
	self:VJ_ACT_PLAYACTIVITY("vjseq_" .. self.SlumpRise,true,false,false)
	local animtime = self:SequenceDuration(self:LookupSequence(self.SlumpRise))
	self.VJ_NoTarget = false
	self:SetArrivalActivity(ACT_IDLE)
	self.SoundTbl_Breath = {"npc/zombie_poison/pz_breathe_loop1.wav","npc/zombie_poison/pz_breathe_loop2.wav"}
	self.SoundTbl_Idle = {"npc/zombie_poison/pz_idle2.wav","npc/zombie_poison/pz_idle3.wav","npc/zombie_poison/pz_idle4.wav"}
	timer.Simple(animtime,function()
		if IsValid(self) then
			self:ResetSlump()
		end
	end)
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnAlert(argent)
	if self.IsSlumped then
		self:UnSlump()
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnTakeDamage_OnBleed(dmginfo,hitgroup)
	if self.IsSlumped then
		self:UnSlump()
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:ResetSlump()
	self.CanFlinch = 1
	self.SightDistance = 10000
	self.SightAngle = 80
	self.MovementType = VJ_MOVETYPE_GROUND
	self.HasMeleeAttack = true
	self.HasRangeAttack = false
	self.HasLeapAttack = false
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:SetUpGibesOnDeath(dmginfo,hitgroup)
	self.HasDeathSounds = false
	if self.HasGibDeathParticles == true then
		local bloodeffect = EffectData()
		bloodeffect:SetOrigin(self:GetPos() +self:OBBCenter())
		bloodeffect:SetColor(VJ_Color2Byte(Color(255,221,35)))
		bloodeffect:SetScale(120)
		util.Effect("VJ_Blood1",bloodeffect)
		
		local bloodspray = EffectData()
		bloodspray:SetOrigin(self:GetPos() +self:OBBCenter())
		bloodspray:SetScale(8)
		bloodspray:SetFlags(3)
		bloodspray:SetColor(1)
		util.Effect("bloodspray",bloodspray)
		util.Effect("bloodspray",bloodspray)
		
		local effectdata = EffectData()
		effectdata:SetOrigin(self:GetPos() +self:OBBCenter())
		effectdata:SetScale(1)
		util.Effect("StriderBlood",effectdata)
		util.Effect("StriderBlood",effectdata)
	end
	
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/agib1.mdl",{BloodType="Yellow",BloodDecal="VJ_HLR_Blood_Yellow",Pos=self:LocalToWorld(Vector(0,0,40))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/agib2.mdl",{BloodType="Yellow",BloodDecal="VJ_HLR_Blood_Yellow",Pos=self:LocalToWorld(Vector(0,0,20))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/agib3.mdl",{BloodType="Yellow",BloodDecal="VJ_HLR_Blood_Yellow",Pos=self:LocalToWorld(Vector(0,0,30))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/agib4.mdl",{BloodType="Yellow",BloodDecal="VJ_HLR_Blood_Yellow",Pos=self:LocalToWorld(Vector(0,0,35))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/agib5.mdl",{BloodType="Yellow",BloodDecal="VJ_HLR_Blood_Yellow",Pos=self:LocalToWorld(Vector(0,0,50))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/agib6.mdl",{BloodType="Yellow",BloodDecal="VJ_HLR_Blood_Yellow",Pos=self:LocalToWorld(Vector(0,0,55))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/agib7.mdl",{BloodType="Yellow",BloodDecal="VJ_HLR_Blood_Yellow",Pos=self:LocalToWorld(Vector(0,0,40))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/agib8.mdl",{BloodType="Yellow",BloodDecal="VJ_HLR_Blood_Yellow",Pos=self:LocalToWorld(Vector(0,0,45))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/agib9.mdl",{BloodType="Yellow",BloodDecal="VJ_HLR_Blood_Yellow",Pos=self:LocalToWorld(Vector(0,0,25))})
	self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/agib10.mdl",{BloodType="Yellow",BloodDecal="VJ_HLR_Blood_Yellow",Pos=self:LocalToWorld(Vector(0,0,15))})
	if self.Zombie_Type == 1 then
		self:CreateGibEntity("obj_vj_gib","models/vj_hlr/gibs/zombiegib.mdl",{BloodType="Yellow",BloodDecal="VJ_HLR_Blood_Yellow",Pos=self:LocalToWorld(Vector(0,0,15))})
	end
	return true -- Return to true if it gibbed!
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomGibOnDeathSounds(dmginfo,hitgroup)
	VJ_EmitSound(self, "vj_gib/default_gib_splat.wav", 90, math.random(100,100))
	return false
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnRemove()
	if self.CurrentBreathSound then self.CurrentBreathSound:Stop() end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:GetHeadcrabCount()
	return self.BlackHeadcrabs
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:ChooseCrab()
	local position = self:GetPos() +Vector(0,0,60)
	-- if self:GetHeadcrabCount() == 3 then
		-- position = self:GetAttachment(self:LookupAttachment("headcrab4")).Pos
	-- elseif self:GetHeadcrabCount() == 2 then
		-- position = self:GetAttachment(self:LookupAttachment("headcrab3")).Pos
	-- elseif self:GetHeadcrabCount() == 1 then
		-- position = self:GetAttachment(self:LookupAttachment("headcrab2")).Pos
	-- end
	return position
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnPriorToKilled(dmginfo,hitgroup)
	self:SetBodygroup(2,0)
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:PoisonHeadcrabAttack(type)
	local throwpos = self:ChooseCrab()
	if type == "throw" then
			self:VJ_ACT_PLAYACTIVITY("vjseq_throw",true,1,false)
			timer.Simple(0.5,function() if self:IsValid() && ((self.VJ_IsBeingControlled == false && IsValid(self:GetEnemy())) or self.VJ_IsBeingControlled == true) then
				self:SetBodygroup(2,1)
					end
				end)
			timer.Simple(1,function() if self:IsValid() && ((self.VJ_IsBeingControlled == false && IsValid(self:GetEnemy())) or self.VJ_IsBeingControlled == true) then
				self:SetBodygroup(2,0)
				local crab = ents.Create("npc_vj_hlr1_headcrab_poison")
				crab:SetPos(throwpos +Vector(0,0,10))
				crab:SetAngles(self:GetAngles())
				crab:Spawn()
				crab:Activate()
				crab:OnThrown(self:GetEnemy(),self)
				self.BlackHeadcrabs = self.BlackHeadcrabs -1
				self:StopAttacks()
					end
				end)
	else
			self:VJ_ACT_PLAYACTIVITY("vjseq_throw",true,1,false)
			timer.Simple(0.5,function() if self:IsValid() && ((self.VJ_IsBeingControlled == false && IsValid(self:GetEnemy())) or self.VJ_IsBeingControlled == true) then
				self:SetBodygroup(2,1)
					end
				end)
			timer.Simple(1,function() if self:IsValid() && ((self.VJ_IsBeingControlled == false && IsValid(self:GetEnemy())) or self.VJ_IsBeingControlled == true) then
				self:SetBodygroup(2,0)
				local crab = ents.Create("npc_vj_hlr1_headcrab_poison")
				crab:SetPos(throwpos +Vector(0,0,10))
				crab:SetAngles(self:GetAngles())
				crab:Spawn()
				crab:Activate()
				crab:OnThrown(self:GetEnemy(),self)
				self.BlackHeadcrabs = self.BlackHeadcrabs -1
				self:StopAttacks()
					end
				end)
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnThink()
	if self.IsSlumped then return end
	if self:GetHeadcrabCount() < 3 && self:GetHeadcrabCount() > 1 then
		self:SetBodygroup(1,2)
	elseif self:GetHeadcrabCount() < 2 && self:GetHeadcrabCount() > 0 then
		self:SetBodygroup(1,1)
	elseif self:GetHeadcrabCount() < 1 then
		self:SetBodygroup(1,0)
	end
	if self.VJ_IsBeingControlled == false then
		self.AnimTbl_Run = {ACT_WALK}
		self.AnimTbl_Walk = {ACT_WALK}
		if IsValid(self:GetEnemy()) && !self.MeleeAttacking then
			if self:GetHeadcrabCount() > 0 && CurTime() > self.NextThrowT && self:GetEnemy():Visible(self) && self:GetEnemy():GetPos():Distance(self:GetPos()) > 200 && self:GetEnemy():GetPos():Distance(self:GetPos()) < 1000 then
				if self:GetEnemy():GetPos():Distance(self:GetPos()) > 500 then
					self:PoisonHeadcrabAttack("throw")
				else
					self:PoisonHeadcrabAttack("leap")
				end
				self.NextThrowT = CurTime() +math.random(8,12)
			end
		end
	else
		if self.VJ_TheController:KeyDown(IN_ATTACK2) && !self.MeleeAttacking && self:GetHeadcrabCount() > 0 && CurTime() > self.NextThrowT then
			if self.VJ_TheControllerBullseye:GetPos():Distance(self:GetPos()) > 500 then
				self:PoisonHeadcrabAttack("throw")
			else
				self:PoisonHeadcrabAttack("leap")
			end
			self.NextThrowT = CurTime() +5
		end
		self.AnimTbl_Run = {VJ_SequenceToActivity(self,"FireWalk")}
		self.AnimTbl_Walk = {ACT_WALK}
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnDeath_AfterCorpseSpawned(dmginfo,hitgroup,GetCorpse)
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnDeath_AfterCorpseSpawned(dmginfo,hitgroup)
	self.Corpse:RemoveAllDecals()
	self.Corpse:DrawShadow(false)
	self.Corpse:SetMaterial("Invisible")
	self.PropGun = ents.Create("obj_warlord_gun")
	self.PropGun:SetModel("models/vj_hlr/hl2old/poison_zombie.mdl")
	self.PropGun:Spawn()
	self.PropGun:SetSubMaterial(0, "models/hl_resurgence/hl1/bodyarmorfnt")
	self.PropGun:SetSubMaterial(1, "models/hl_resurgence/hl1/pantfront")
	self.PropGun:SetSubMaterial(4, "models/hl_resurgence/hl1/bodyarmorfnt")
	self.PropGun:SetSubMaterial(5, "models/hl_resurgence/hl1/pantfront")
	self.PropGun:SetSubMaterial(7, "models/hl_resurgence/hl1/pantfront")
	self.PropGun:SetSubMaterial(8, "models/hl_resurgence/hl1/pantfront")
	self.PropGun:SetSubMaterial(9, "models/hl_resurgence/hl1/bootside")
	self.PropGun:SetSubMaterial(10, "models/hl_resurgence/hl1/pantfront")
	self.PropGun:SetSubMaterial(11, "models/hl_resurgence/hl1/pantfront")
	self.PropGun:SetParent(self.Corpse)
	self.PropGun:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
		self.PropGun:SetBodygroup(1,3)
	if self:GetHeadcrabCount() < 3 && self:GetHeadcrabCount() > 1 then
		self.PropGun:SetBodygroup(1,2)
	elseif self:GetHeadcrabCount() < 2 && self:GetHeadcrabCount() > 0 then
		self.PropGun:SetBodygroup(1,1)
	elseif self:GetHeadcrabCount() < 1 then
		self.PropGun:SetBodygroup(1,0)
	end
end
/*-----------------------------------------------
	*** Copyright (c) 2012-2017 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/